## RECON

```shell
nmap -sC -sV -Pn -p- -oA full_scal_all 10.4.10.10-12, 22-23
```

- -sC "use default scripts"
- -sV "do a service version scan"
- -Pn "noPing scan"
- -p- "scan all ports"
- -oA "save output to full_scan_all"
